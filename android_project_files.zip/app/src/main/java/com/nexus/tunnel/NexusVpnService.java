package com.nexus.tunnel;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.os.PowerManager;
import android.util.Log;

public class NexusVpnService extends VpnService {
    private static final String TAG = "NexusVpnService";
    public static final String ACTION_CONNECT = "com.nexus.tunnel.VPN_CONNECT";
    public static final String ACTION_DISCONNECT = "com.nexus.tunnel.VPN_DISCONNECT";
    public static final String CHANNEL_ID = "nexus_tunnel_vpn_channel";
    public static final int NOTIFICATION_ID = 8802;

    private ParcelFileDescriptor vpnInterface = null;
    private PowerManager.WakeLock wakeLock = null;
    private Thread workerThread = null;
    private volatile boolean isRunning = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_DISCONNECT.equals(intent.getAction())) {
            stopTunnelVpn();
            return START_NOT_STICKY;
        }

        startTunnelVpn();
        return START_STICKY;
    }

    private synchronized void startTunnelVpn() {
        if (isRunning) return;
        isRunning = true;

        // 1. Acquire WakeLock to keep background connection active during gameplay
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null && (wakeLock == null || !wakeLock.isHeld())) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "NexusTunnel:VpnWakeLock");
                wakeLock.acquire(180 * 60 * 1000L); // 3 hours
            }
        } catch (Exception ignored) {}

        // 2. Start Foreground Notification
        Intent notificationIntent = new Intent(this, MainActivity.class);
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, notificationIntent,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0
        );

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        Notification notification = builder
                .setContentTitle("Nexus Tunnel Connected")
                .setContentText("Protected stealth session active in background")
                .setSmallIcon(getApplicationInfo().icon != 0 ? getApplicationInfo().icon : android.R.drawable.ic_lock_lock)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();

        startForeground(NOTIFICATION_ID, notification);

        // 3. Establish VPN Interface to activate system status bar VPN key icon next to Wi-Fi
        try {
            if (vpnInterface == null) {
                Builder vpnBuilder = new Builder();
                vpnBuilder.setSession("Nexus Tunnel");
                vpnBuilder.addAddress("10.200.0.2", 32);
                vpnBuilder.addRoute("10.200.0.0", 24);
                vpnBuilder.setMtu(1500);

                vpnInterface = vpnBuilder.establish();
                Log.d(TAG, "Nexus Tunnel VPN interface established. System status bar key icon active.");
            }

            if (workerThread == null || !workerThread.isAlive()) {
                workerThread = new Thread(() -> {
                    try {
                        while (isRunning && vpnInterface != null) {
                            Thread.sleep(1000);
                        }
                    } catch (InterruptedException ignored) {}
                }, "NexusVpnWorker");
                workerThread.start();
            }

        } catch (Exception e) {
            Log.e(TAG, "Failed to establish VPN interface: ", e);
        }
    }

    private synchronized void stopTunnelVpn() {
        isRunning = false;

        if (workerThread != null) {
            workerThread.interrupt();
            workerThread = null;
        }

        if (vpnInterface != null) {
            try {
                vpnInterface.close();
            } catch (Exception ignored) {}
            vpnInterface = null;
        }

        if (wakeLock != null && wakeLock.isHeld()) {
            try {
                wakeLock.release();
            } catch (Exception ignored) {}
            wakeLock = null;
        }

        stopForeground(true);
        stopSelf();
        Log.d(TAG, "Nexus Tunnel VPN stopped and key icon dismissed.");
    }

    @Override
    public void onDestroy() {
        stopTunnelVpn();
        super.onDestroy();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Nexus Tunnel VPN Service",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Maintains secure tunnel and status bar icon during gameplay");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }
}
