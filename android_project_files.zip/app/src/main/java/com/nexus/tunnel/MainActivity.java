package com.nexus.tunnel;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {

    private static final String TAG = "NexusTunnel";
    private static final String PREFS_NAME = "NexusPrefs";
    private static final String KEY_SAVED_LICENSE = "saved_license_key";
    private static final int REQUEST_CODE_PICK_FOLDER = 202;

    // =========================================================================
    // SERVER CONFIGURATION & DOWNLOAD URL (CHANGE HERE!)
    // =========================================================================
    public static final String BASE_URL = "https://pubg.pakistanhandicraftbrass.com";
    public static final String CUSTOM_DOWNLOAD_URL = ""; 

    public static final String API_VERIFY_ENDPOINT = BASE_URL + "/api/index.php?endpoint=verify_key";
    public static final String API_DOWNLOAD_FALLBACK = BASE_URL + "/api/patch/download";
    public static final String API_DOWNLOAD_FALLBACK2 = BASE_URL + "/server_api.php?action=download";

    // =========================================================================
    // MOBILE STORAGE TARGET PATH CONFIGURATION (MANUAL EDITING REFERENCE)
    // =========================================================================
    // LINE 78: Subfolder path inside UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/
    // Default is "Saved/Paks". If you want the files placed directly in files/, set to "" or "files".
    public static final String SUB_TARGET_PATH = "Saved/Paks";

    // LINE 82: MASTER CUSTOM FOLDER OVERRIDE (EXACT PATH APPLIED)
    public static final String CUSTOM_STORAGE_SAVE_PATH = "/storage/emulated/0/Android/data/com.tencent.ig";

    // LINES 87-93: Game Package Names to auto-detect if CUSTOM_STORAGE_SAVE_PATH is empty
    private static final String[] TARGET_PACKAGES = {
            "com.tencent.ig",       // Global
            "com.pubg.imobile",     // BGMI (India)
            "com.pubg.krmobile",    // KR / JP
            "com.vng.pubgmobile",   // Vietnam
            "com.rekoo.pubgm"       // Taiwan
    };

    private WebView webView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ScheduledExecutorService heartbeatScheduler = Executors.newSingleThreadScheduledExecutor();
    private ScheduledFuture<?> heartbeatTask = null;

    private final List<String> deployedFilesList = new ArrayList<>();
    private final List<String> deployedDirsList = new ArrayList<>();
    private final List<String> deployedUrisList = new ArrayList<>();
    private volatile File currentTargetPaksDir = null;
    private volatile boolean isSessionActive = false;
    private volatile String currentActiveKey = "";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Immersive Full Screen
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);

        // Keep screen active while tunneling
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        webView = new WebView(this);
        setContentView(webView);

        initWebView();
        requestAppPermissions();

        // Load Frosted Glass UI from Assets
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void initWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setBackgroundColor(0xFF030712); // match deep background

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });

        // Register Java <-> JavaScript Bridge
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
    }

    private void requestAppPermissions() {
        // 1. Android 11+ (API 30+ / Android R and above): Request All Files Access (MANAGE_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivityForResult(intent, 102);
                } catch (Exception e) {
                    try {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                        startActivityForResult(intent, 102);
                    } catch (Exception ignored) {}
                }
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            // 2. Android 6 to Android 10: Request standard Read/Write External Storage permissions
            List<String> perms = new ArrayList<>();
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                perms.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
            }
            if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                perms.add(android.Manifest.permission.READ_EXTERNAL_STORAGE);
            }
            if (!perms.isEmpty()) {
                requestPermissions(perms.toArray(new String[0]), 101);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 101) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                sendTerminalLog("PERM", "Storage read/write permission granted.", "ok");
            } else {
                sendTerminalLog("PERM", "Storage permission was denied.", "warn");
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 102) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    sendTerminalLog("PERM", "Full Storage Access (All Files) granted by user.", "ok");
                    Toast.makeText(this, "Storage Access Granted!", Toast.LENGTH_SHORT).show();
                } else {
                    sendTerminalLog("PERM", "Full Storage Access was not enabled.", "warn");
                }
            }
            return;
        }
        if (requestCode == REQUEST_CODE_PICK_FOLDER && resultCode == RESULT_OK && data != null) {
            Uri treeUri = data.getData();
            if (treeUri != null) {
                try {
                    getContentResolver().takePersistableUriPermission(
                            treeUri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    );
                } catch (Exception ignored) {}

                String path = null;
                try {
                    String docId = DocumentsContract.getTreeDocumentId(treeUri);
                    if (docId != null && docId.startsWith("primary:")) {
                        path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + docId.substring("primary:".length());
                    }
                } catch (Exception ignored) {}
                if (path == null) {
                    path = treeUri.getPath();
                }

                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                prefs.edit()
                        .putString("manual_target_path", path != null ? path : "")
                        .putString("manual_target_uri", treeUri.toString())
                        .apply();

                sendTerminalLog("CONFIG", "Game directory assigned: " + (path != null ? path : treeUri.toString()), "ok");

                final String finalPath = path;
                mainHandler.post(() -> {
                    if (webView != null) {
                        webView.evaluateJavascript("if (window.onFolderSelected) window.onFolderSelected('"
                                + (finalPath != null ? finalPath.replace("\\", "\\\\") : "Folder Assigned") + "');", null);
                    }
                });

                // Automatically attempt connect if key is available
                if (!currentActiveKey.isEmpty() && !isSessionActive) {
                    executor.execute(() -> performConnectAndDeploy(currentActiveKey));
                }
            }
        }
    }

    // =========================================================================
    // JAVASCRIPT BRIDGE INTERFACE
    // =========================================================================
    public class AndroidBridge {
        @JavascriptInterface
        public String getClipboardText() {
            final String[] result = {""};
            try {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null && clipboard.hasPrimaryClip()) {
                    ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
                    if (item != null && item.getText() != null) {
                        result[0] = item.getText().toString().trim();
                    }
                }
            } catch (Exception ignored) {}
            return result[0];
        }

        @JavascriptInterface
        public void verifyKeyOnly(final String key) {
            if (key == null || key.trim().isEmpty()) {
                mainHandler.post(() -> {
                    webView.evaluateJavascript("if(window.onNativeKeyResult){window.onNativeKeyResult(false, 'Key cannot be empty', 0);}", null);
                });
                return;
            }
            executor.execute(() -> {
                try {
                    String hwid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                    if (hwid == null || hwid.isEmpty()) hwid = "ANDROID-" + Build.SERIAL;
                    String deviceName = Build.MANUFACTURER + " " + Build.MODEL;

                    String postData = "action=" + URLEncoder.encode("verify_key", "UTF-8")
                            + "&key=" + URLEncoder.encode(key.trim(), "UTF-8")
                            + "&hwid=" + URLEncoder.encode(hwid, "UTF-8")
                            + "&device_name=" + URLEncoder.encode(deviceName, "UTF-8");

                    URL url = new URL(API_VERIFY_ENDPOINT);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(8000);
                    conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                    try (OutputStream os = conn.getOutputStream()) {
                        os.write(postData.getBytes(StandardCharsets.UTF_8));
                        os.flush();
                    }

                    int code = conn.getResponseCode();
                    if (code == 200) {
                        StringBuilder sb = new StringBuilder();
                        try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                            String line;
                            while ((line = reader.readLine()) != null) sb.append(line);
                        }
                        JSONObject json = new JSONObject(sb.toString());
                        String status = json.optString("status", "").toUpperCase();
                        String errMsg = json.optString("message", "Invalid key");
                        long remainingSecs = json.optLong("remaining_seconds", 0);

                        if ("SUCCESS".equals(status) || json.optBoolean("valid", false)) {
                            saveKey(key.trim());
                            mainHandler.post(() -> {
                                webView.evaluateJavascript(String.format(
                                        "if(window.onNativeKeyResult){window.onNativeKeyResult(true, 'VIP License verified & active!', %d);}",
                                        remainingSecs
                                ), null);
                            });
                        } else {
                            clearSavedKey();
                            final String failMsg = errMsg;
                            mainHandler.post(() -> {
                                webView.evaluateJavascript(String.format(
                                        "if(window.onNativeKeyResult){window.onNativeKeyResult(false, '%s', 0);}",
                                        escapeJs(failMsg)
                                ), null);
                            });
                        }
                    } else {
                        mainHandler.post(() -> {
                            webView.evaluateJavascript("if(window.onNativeKeyResult){window.onNativeKeyResult(false, 'Server error (HTTP " + code + ")', 0);}", null);
                        });
                    }
                } catch (Exception e) {
                    final String exMsg = e.getMessage();
                    mainHandler.post(() -> {
                        webView.evaluateJavascript(String.format(
                                "if(window.onNativeKeyResult){window.onNativeKeyResult(false, 'Connection error: %s', 0);}",
                                escapeJs(exMsg)
                        ), null);
                    });
                }
            });
        }


        @JavascriptInterface
        public void openFolderPicker() {
            mainHandler.post(() -> {
                try {
                    sendTerminalLog("CONFIG", "Opening manual folder picker for com.tencent.ig...", "warn");
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(intent, REQUEST_CODE_PICK_FOLDER);
                } catch (Exception e) {
                    sendTerminalLog("ERR", "Cannot open folder picker: " + e.getMessage(), "err");
                    Toast.makeText(MainActivity.this, "Folder picker unavailable.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public String getSavedFolder() {
            return "Android/data/com.tencent.ig";
        }

        @JavascriptInterface
        public String getSavedKey() {
            // Strictly return empty string to prevent displaying stale/recent key history
            return "";
        }

        @JavascriptInterface
        public void saveKey(String key) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            if (key == null || key.trim().isEmpty()) {
                prefs.edit().remove(KEY_SAVED_LICENSE).apply();
            } else {
                prefs.edit().putString(KEY_SAVED_LICENSE, key.trim()).apply();
            }
        }

        @JavascriptInterface
        public void clearSavedKey() {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            prefs.edit().remove(KEY_SAVED_LICENSE).apply();
        }

        @JavascriptInterface
        public void copyToClipboard(String text) {
            mainHandler.post(() -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null) {
                    ClipData clip = ClipData.newPlainText("Nexus Logs", text);
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(MainActivity.this, "Copied to Clipboard!", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void connect(final String key) {
            if (isSessionActive) {
                Log.w(TAG, "Connection session already active.");
                return;
            }
            currentActiveKey = key != null ? key.trim() : "";
            executor.execute(() -> performConnectAndDeploy(currentActiveKey));
        }

        @JavascriptInterface
        public void disconnect() {
            stopHeartbeat();
            executor.execute(() -> performDisconnectAndClean());
        }
    }

    // =========================================================================
    // 2-SECOND BACKGROUND KEY HEARTBEAT & AUTO-PURGE
    // =========================================================================
    private void startHeartbeat(final String key, final String hwid) {
        stopHeartbeat();
        // Check every 2 seconds for instantaneous revocation & wipe
        heartbeatTask = heartbeatScheduler.scheduleWithFixedDelay(() -> {
            if (!isSessionActive) return;
            try {
                boolean isVpn = isVpnActive();
                String postData = "action=" + URLEncoder.encode("verify_key", "UTF-8")
                        + "&key=" + URLEncoder.encode(key, "UTF-8")
                        + "&hwid=" + URLEncoder.encode(hwid, "UTF-8")
                        + "&is_vpn=" + (isVpn ? "1" : "0");

                URL url = new URL(API_VERIFY_ENDPOINT);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(2000);
                conn.setReadTimeout(2000);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(postData.getBytes(StandardCharsets.UTF_8));
                    os.flush();
                }

                int code = conn.getResponseCode();
                boolean stillValid = false;
                String errorReason = "KEY NOT FOUND - System deactivated by Administrator!";
                boolean isBanned = false;

                if (code == 200) {
                    StringBuilder sb = new StringBuilder();
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line);
                        }
                    }
                    JSONObject json = new JSONObject(sb.toString());
                    String status = json.optString("status", "").toUpperCase();
                    String errCode = json.optString("error_code", "");

                    if ("SUCCESS".equals(status) || "OK".equals(status) || json.optBoolean("valid", false)) {
                        stillValid = true;
                    } else {
                        if ("IP_BANNED".equals(errCode)) {
                            errorReason = "ACCESS BLOCKED: Your IP address has been BANNED by Administrator!";
                            isBanned = true;
                        } else if ("DEVICE_BANNED".equals(errCode)) {
                            errorReason = "ACCESS BLOCKED: Device Hardware MAC/HWID has been BANNED by Administrator!";
                            isBanned = true;
                        } else if ("DEVICE_LOCKED".equals(errCode)) {
                            errorReason = "1-DEVICE LOCK: Key is active on another device!";
                        } else {
                            errorReason = "KEY NOT FOUND: License key was deleted or revoked by Administrator!";
                        }
                    }
                }

                if (!stillValid) {
                    Log.w(TAG, "Heartbeat check FAILED within 2s: " + errorReason);
                    sendTerminalLog("SECURITY", errorReason, "err");
                    sendTerminalLog("PURGE", "Emergency 2-Second wipe activated. Permanently purging storage...", "err");

                    // 1. Immediately delete all deployed files & deep wipe directory
                    performDisconnectAndClean();

                    // 2. Clear saved key in SharedPreferences on ban/revocation
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                    prefs.edit().remove(KEY_SAVED_LICENSE).apply();

                    // 3. Stop heartbeat
                    stopHeartbeat();

                    // 4. Notify UI
                    if (isBanned) {
                        notifyDeviceBanned(errorReason);
                    } else {
                        notifyKeyRevoked(errorReason);
                    }
                }

            } catch (Exception e) {
                Log.d(TAG, "Heartbeat poll glitch: " + e.getMessage());
            }
        }, 2, 2, TimeUnit.SECONDS);
    }

    private void stopHeartbeat() {
        if (heartbeatTask != null && !heartbeatTask.isCancelled()) {
            heartbeatTask.cancel(true);
            heartbeatTask = null;
        }
    }

    // =========================================================================
    // CONNECT, VERIFY, DOWNLOAD & UNZIP PIPELINE
    // =========================================================================
    private void performConnectAndDeploy(String key) {
        try {
            // Android 6 to 10 Runtime Permission Check
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    sendTerminalLog("PERM", "Storage write permission required. Requesting permission...", "warn");
                    mainHandler.post(this::requestAppPermissions);
                    notifyError("Storage permission required. Please grant storage access.");
                    return;
                }
            }

            sendTerminalLog("CONNECT", "Initiating secure handshake...", "warn");
            sendTerminalLog("PERMISSION", "Storage access verified from device.", "ok");

            String hwid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            if (hwid == null || hwid.isEmpty()) {
                hwid = "ANDROID-" + Build.SERIAL;
            }
            String deviceName = Build.MANUFACTURER + " " + Build.MODEL;

            // 1. Send API Verification Request
            sendTerminalLog("AUTH", "Verifying license key with security gateway...", "warn");

            String downloadUrl = null;
            String serverFileName = "game_patch_4.6.0.21561.pak";
            long remainingSeconds = 30 * 86400L;
            boolean isAuthorized = false;

            try {
                String postData = "action=" + URLEncoder.encode("verify_key", "UTF-8")
                        + "&key=" + URLEncoder.encode(key.trim(), "UTF-8")
                        + "&hwid=" + URLEncoder.encode(hwid, "UTF-8")
                        + "&device_name=" + URLEncoder.encode(deviceName, "UTF-8");

                URL url = new URL(API_VERIFY_ENDPOINT);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(12000);
                conn.setReadTimeout(12000);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestProperty("User-Agent", "NEXUS-TUNNEL/3.0.0 (Android " + Build.VERSION.RELEASE + ")");

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(postData.getBytes(StandardCharsets.UTF_8));
                    os.flush();
                }

                int responseCode = conn.getResponseCode();
                if (responseCode == 200) {
                    StringBuilder sb = new StringBuilder();
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line);
                        }
                    }

                    JSONObject json = new JSONObject(sb.toString());
                    String status = json.optString("status", "").toUpperCase();
                    String errorCode = json.optString("error_code", "");

                    if ("SUCCESS".equals(status) || "OK".equals(status) || json.optBoolean("valid", false)) {
                        isAuthorized = true;
                        if (json.has("download_url")) {
                            downloadUrl = json.getString("download_url");
                        } else if (json.has("file_url")) {
                            downloadUrl = json.getString("file_url");
                        }
                        if (json.has("filename")) {
                            serverFileName = json.getString("filename");
                        } else if (json.has("original_name")) {
                            serverFileName = json.getString("original_name");
                        }
                        if (json.has("remaining_seconds")) {
                            remainingSeconds = json.getLong("remaining_seconds");
                        }
                        sendTerminalLog("AUTH", "VIP Key successfully authenticated & hardware bound.", "ok");
                    } else {
                        String errMsg = "License authorization failed: KEY NOT FOUND.";
                        if ("IP_BANNED".equals(errorCode)) {
                            errMsg = "ACCESS BLOCKED: Your IP Address has been BANNED by Administrator!";
                        } else if ("DEVICE_BANNED".equals(errorCode)) {
                            errMsg = "ACCESS BLOCKED: Hardware MAC/HWID has been BANNED by Administrator!";
                        } else if ("DEVICE_LOCKED".equals(errorCode)) {
                            errMsg = "1-DEVICE LOCK: Key bound to another device!";
                        } else if ("EXPIRED".equals(status)) {
                            errMsg = "KEY EXPIRED: Please purchase a new VIP key.";
                        }
                        sendTerminalLog("FAIL", errMsg, "err");
                        notifyError(errMsg);
                        return;
                    }
                } else {
                    sendTerminalLog("FAIL", "Server verification returned HTTP " + responseCode, "err");
                    notifyError("Server verification returned HTTP " + responseCode);
                    return;
                }
            } catch (Exception e) {
                Log.e(TAG, "API verification network error: ", e);
                sendTerminalLog("FAIL", "Cannot connect to security gateway: " + e.getMessage(), "err");
                notifyError("Connection failed: Server unreachable.");
                return;
            }

            if (!isAuthorized) {
                notifyError("KEY NOT FOUND - Invalid license key.");
                return;
            }

            if (CUSTOM_DOWNLOAD_URL != null && !CUSTOM_DOWNLOAD_URL.trim().isEmpty()) {
                downloadUrl = CUSTOM_DOWNLOAD_URL.trim();
                Log.d(TAG, "Using custom download URL: " + downloadUrl);
            }

            // 2. Direct Target Game Directory (Fixed directly to com.tencent.ig)
            File targetDir = resolveTargetPaksDirectory();

            // If path can't be auto-resolved, open SAF picker as fallback
            if (targetDir == null) {
                String errMsg = "Target directory not found: " + TARGET_BASE_PATH + "\nPlease select the com.tencent.ig folder manually.";
                sendTerminalLog("ERR", errMsg, "err");
                // Save the key so deploy can auto-resume after folder selection
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                prefs.edit().putString(KEY_SAVED_LICENSE, key).apply();
                mainHandler.post(() -> {
                    Toast.makeText(MainActivity.this,
                            "Game folder not found. Please select com.tencent.ig folder manually.",
                            Toast.LENGTH_LONG).show();
                    notifyError("Game folder not found. Tap the folder icon to select com.tencent.ig manually.");
                    // Open SAF folder picker
                    try {
                        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                        startActivityForResult(intent, REQUEST_CODE_PICK_FOLDER);
                    } catch (Exception e) {
                        sendTerminalLog("ERR", "Cannot open folder picker: " + e.getMessage(), "err");
                        notifyError("Cannot open folder picker. Please grant storage permission.");
                    }
                });
                return;
            }

            currentTargetPaksDir = targetDir;
            sendTerminalLog("TARGET", "Target Directory: " + targetDir.getAbsolutePath(), "ok");

            // 3. Download Server Payload to private cache
            sendTerminalLog("DOWNLOAD", "Fetching payload from server...", "warn");

            File cacheDir = getCacheDir();
            File tempPayload = new File(cacheDir, ".core_module.tmp");
            boolean downloadSuccess = false;

            String[] candidateUrls = {
                    downloadUrl,
                    API_DOWNLOAD_FALLBACK,
                    API_DOWNLOAD_FALLBACK2,
                    BASE_URL + "/files/patch_package.zip",
                    BASE_URL + "/files/game_patch.pak",
                    BASE_URL + "/files/game_patch_4.6.0.21561.pak",
                    BASE_URL + "/files/game_patch.zip"
            };

            for (String testUrl : candidateUrls) {
                if (testUrl == null || testUrl.isEmpty()) continue;
                try {
                    Log.d(TAG, "Attempting payload download from: " + testUrl);
                    URL u = new URL(testUrl);
                    HttpURLConnection dConn = (HttpURLConnection) u.openConnection();
                    dConn.setConnectTimeout(15000);
                    dConn.setReadTimeout(30000);
                    dConn.setRequestProperty("User-Agent", "NEXUS-TUNNEL/3.0.0");
                    if (dConn.getResponseCode() == 200) {
                        try (InputStream in = new BufferedInputStream(dConn.getInputStream());
                             OutputStream out = new BufferedOutputStream(new FileOutputStream(tempPayload))) {
                            byte[] buffer = new byte[8192];
                            int read;
                            while ((read = in.read(buffer)) != -1) {
                                out.write(buffer, 0, read);
                            }
                            out.flush();
                        }
                        if (tempPayload.exists() && tempPayload.length() > 0) {
                            downloadSuccess = true;
                            sendTerminalLog("IDENTIFY", "Payload synchronized: " + (tempPayload.length() / 1024) + " KB.", "info");
                            break;
                        }
                    }
                } catch (Exception ex) {
                    Log.w(TAG, "Download failed from " + testUrl + ": " + ex.getMessage());
                }
            }

            // 4. DEPLOY / EXTRACT PAYLOAD INTO TARGET DIRECTORY
            sendTerminalLog("STEALTH", "[STEP 1/2] Connecting stealth payload stream...", "warn");
            deployedFilesList.clear();
            deployedDirsList.clear();
            deployedUrisList.clear();

            if (downloadSuccess && tempPayload.exists()) {
                boolean isZip = isZipFile(tempPayload);
                
                if (isZip) {
                    sendTerminalLog("DEPLOY", "[STEP 2/2] Extracting folder archive into: " + targetDir.getAbsolutePath(), "warn");
                    boolean ok = unzipToDirectory(tempPayload, targetDir);
                    if (!ok) {
                        sendTerminalLog("ERR", "Unzip extraction had issues. Check terminal logs above.", "err");
                    }
                } else {
                    sendTerminalLog("DEPLOY", "[STEP 2/2] Pasting .PAK directly into: " + targetDir.getAbsolutePath(), "warn");
                    String targetPakName = (serverFileName != null && !serverFileName.trim().isEmpty()) ? serverFileName.trim() : "game_patch.pak";
                    File destPak = new File(targetDir, targetPakName);
                    copyFile(tempPayload, destPak);
                    try {
                        destPak.setReadable(true, false);
                        destPak.setWritable(false, false);
                        Runtime.getRuntime().exec(new String[]{"chmod", "444", destPak.getAbsolutePath()});
                    } catch (Exception ignored) {}
                    deployedFilesList.add(destPak.getAbsolutePath());
                    sendTerminalLog("SAVED", destPak.getAbsolutePath() + " (" + (destPak.length() / 1024) + " KB)", "ok");
                }

                // Delete temp cache immediately
                if (tempPayload.exists()) {
                    tempPayload.delete();
                }

                File tokenFile = new File(targetDir, "nexus_session.cfg");
                try (FileOutputStream fos = new FileOutputStream(tokenFile)) {
                    fos.write(("NEXUS_SESSION=ACTIVE\nKEY=" + key + "\nTIMESTAMP=" + System.currentTimeMillis()).getBytes());
                } catch (Exception ignored) {}
                deployedFilesList.add(tokenFile.getAbsolutePath());
            } else {
                sendTerminalLog("FAIL", "Payload download failed from all server endpoints!", "err");
                notifyError("Payload download failed. Please check internet connection.");
                return;
            }

            // 5. Complete & Start 2-Second Heartbeat
            isSessionActive = true;
            sendTerminalLog("STEALTH", "Payload deployed directly into: " + targetDir.getAbsolutePath(), "ok");
            sendTerminalLog("SECURE", "Non-copyable stealth protection active. 0 traces.", "ok");
            sendTerminalLog("NET", "Tunnel routing 100% ACTIVE and secured.", "ok");
            notifyConnected(remainingSeconds);

            // Start 2-second monitoring heartbeat
            startHeartbeat(key, hwid);

        } catch (Exception e) {
            Log.e(TAG, "Error in performConnectAndDeploy: ", e);
            sendTerminalLog("FAIL", "Deployment failed: " + e.getMessage(), "err");
            notifyError("Deployment failed: " + e.getMessage());
        }
    }

    private synchronized void performDisconnectAndClean() {
        try {
            sendTerminalLog("DISCONNECT", "Stopping tunnel session & wiping injected data...", "warn");
            if (isRootAvailable()) {
                String targetPkg = getDetectedGamePackage();
                String rootTarget = "/sdcard/Android/data/" + targetPkg + "/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/";
                executeRootCommand("rm -f " + rootTarget + "game_patch*.pak");
                executeRootCommand("rm -f " + rootTarget + "nexus_session.cfg");
                sendTerminalLog("ROOT", "[WIPE] Root Shell: All stealth payload files wiped from Saved/Paks.", "clean");
            }

            // 1. Purge all deployed files recorded in list
            for (String filePath : deployedFilesList) {
                try {
                    File f = new File(filePath);
                    if (f.exists()) {
                        f.setWritable(true, false);
                        f.delete();
                        Log.d(TAG, "Permanently purged file: " + filePath);
                    }
                } catch (Exception ignored) {}
            }
            deployedFilesList.clear();

            // 2. Purge all empty subdirectories created during extraction
            for (String dirPath : deployedDirsList) {
                try {
                    File d = new File(dirPath);
                    if (d.exists() && d.isDirectory()) {
                        File[] remaining = d.listFiles();
                        if (remaining == null || remaining.length == 0) {
                            d.setWritable(true, false);
                            d.delete();
                            Log.d(TAG, "Cleaned empty injected directory: " + dirPath);
                        }
                    }
                } catch (Exception ignored) {}
            }
            deployedDirsList.clear();

            // 3. Purge all SAF document URIs created
            for (String uriStr : deployedUrisList) {
                try {
                    Uri u = Uri.parse(uriStr);
                    DocumentsContract.deleteDocument(getContentResolver(), u);
                    Log.d(TAG, "Permanently purged SAF document: " + uriStr);
                } catch (Exception ignored) {}
            }
            deployedUrisList.clear();

            // 4. Scan target folder and wipe all session and stealth pak data
            if (currentTargetPaksDir != null && currentTargetPaksDir.exists()) {
                try {
                    File[] files = currentTargetPaksDir.listFiles();
                    if (files != null) {
                        for (File rf : files) {
                            if (rf.isFile()) {
                                String name = rf.getName().toLowerCase();
                                if (name.startsWith("game_patch") || name.startsWith("nexus_") || name.startsWith("patch_")
                                        || name.endsWith(".pak") || name.endsWith(".tmp") || name.equals(".nomedia") || name.equals("nexus_session.cfg")) {
                                    rf.setWritable(true, false);
                                    rf.delete();
                                    Log.d(TAG, "Wiped stealth file from target folder: " + rf.getAbsolutePath());
                                }
                            }
                        }
                    }
                } catch (Exception ignored) {}
            }

            // 5. Clean cache payload
            File tempPayload = new File(getCacheDir(), ".core_module.tmp");
            if (tempPayload.exists()) {
                tempPayload.delete();
            }

            isSessionActive = false;
            sendTerminalLog("CLEAN", "[WIPE] Stealth Data Wiped: All injected game payload data wiped from folder.", "clean");
            notifyDisconnected();

        } catch (Exception e) {
            Log.e(TAG, "Error in disconnect: ", e);
            notifyDisconnected();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (isSessionActive) {
            Log.i(TAG, "App backgrounded/switched: Triggering instant data wipe");
            performDisconnectAndClean();
        }
    }

    @Override
    protected void onDestroy() {
        if (isSessionActive) {
            performDisconnectAndClean();
        }
        stopHeartbeat();
        executor.shutdown();
        heartbeatScheduler.shutdown();
        super.onDestroy();
    }

    // =========================================================================
    
    // =========================================================================
    // ROOT / SUPERUSER STORAGE BYPASS ENGINE (For Android 13/14 & Rooted Devices)
    // =========================================================================
    public static boolean isRootAvailable() {
        Process process = null;
        try {
            process = Runtime.getRuntime().exec(new String[]{"su", "-c", "id"});
            java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(process.getInputStream()));
            String line = reader.readLine();
            int exitVal = process.waitFor();
            return (exitVal == 0 && line != null && line.contains("uid=0"));
        } catch (Exception e) {
            return false;
        } finally {
            if (process != null) process.destroy();
        }
    }

    public static boolean executeRootCommand(String command) {
        Process process = null;
        java.io.DataOutputStream os = null;
        try {
            process = Runtime.getRuntime().exec("su");
            os = new java.io.DataOutputStream(process.getOutputStream());
            os.writeBytes(command + "\n");
            os.writeBytes("exit\n");
            os.flush();
            int exitVal = process.waitFor();
            return exitVal == 0;
        } catch (Exception e) {
            Log.e("NexusTunnel", "Root command failed: " + e.getMessage());
            return false;
        } finally {
            try {
                if (os != null) os.close();
                if (process != null) process.destroy();
            } catch (Exception ignored) {}
        }
    }

    // =========================================================================
    // SAF DOCUMENT TREE & ARCHIVE HELPER METHODS
    // =========================================================================
    private Uri findChildDocument(Uri treeUri, String parentDocId, String displayName) {
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId);
        android.database.Cursor cursor = null;
        try {
            cursor = getContentResolver().query(
                    childrenUri,
                    new String[]{
                            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                            DocumentsContract.Document.COLUMN_DISPLAY_NAME
                    },
                    null, null, null
            );
            if (cursor != null) {
                int idCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                int nameCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                while (cursor.moveToNext()) {
                    String name = cursor.getString(nameCol);
                    if (displayName.equalsIgnoreCase(name)) {
                        String docId = cursor.getString(idCol);
                        return DocumentsContract.buildDocumentUriUsingTree(treeUri, docId);
                    }
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "findChildDocument query error: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
        }
        return null;
    }

    private Uri findOrCreateSubDir(Uri treeUri, Uri parentDocUri, String dirName) {
        try {
            String parentDocId = DocumentsContract.getDocumentId(parentDocUri);
            Uri existing = findChildDocument(treeUri, parentDocId, dirName);
            if (existing != null) {
                return existing;
            }
            Uri created = DocumentsContract.createDocument(getContentResolver(), parentDocUri, DocumentsContract.Document.MIME_TYPE_DIR, dirName);
            if (created != null) {
                deployedUrisList.add(created.toString());
                return created;
            }
        } catch (Exception e) {
            Log.e(TAG, "findOrCreateSubDir error for '" + dirName + "': ", e);
        }
        return null;
    }

    private Uri findOrCreateFile(Uri treeUri, Uri parentDocUri, String mimeType, String fileName) {
        try {
            String parentDocId = DocumentsContract.getDocumentId(parentDocUri);
            Uri existing = findChildDocument(treeUri, parentDocId, fileName);
            if (existing != null) {
                return existing;
            }
            Uri created = DocumentsContract.createDocument(getContentResolver(), parentDocUri, mimeType, fileName);
            if (created != null) {
                deployedUrisList.add(created.toString());
                return created;
            }
        } catch (Exception e) {
            Log.e(TAG, "findOrCreateFile error for '" + fileName + "': ", e);
        }
        return null;
    }

    private Uri copyFileToDocumentTree(File src, Uri treeUri, String fileName) {
        try {
            String rootDocId = DocumentsContract.getTreeDocumentId(treeUri);
            Uri rootDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootDocId);
            Uri fileUri = findOrCreateFile(treeUri, rootDocUri, "application/octet-stream", fileName);
            if (fileUri != null) {
                try (InputStream in = new FileInputStream(src);
                     OutputStream out = getContentResolver().openOutputStream(fileUri, "wt")) {
                    byte[] buf = new byte[8192];
                    int len;
                    while ((len = in.read(buf)) > 0) {
                        out.write(buf, 0, len);
                    }
                    out.flush();
                }
                return fileUri;
            }
        } catch (Exception e) {
            Log.e(TAG, "copyFileToDocumentTree error: ", e);
        }
        return null;
    }

    private boolean unzipToDocumentTree(File zipFile, Uri treeUri) {
        if (zipFile == null || !zipFile.exists() || treeUri == null) return false;
        try (ZipInputStream zis = new ZipInputStream(new BufferedInputStream(new FileInputStream(zipFile)))) {
            String rootDocId = DocumentsContract.getTreeDocumentId(treeUri);
            Uri rootDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootDocId);

            ZipEntry entry;
            byte[] buffer = new byte[8192];
            int count = 0;

            while ((entry = zis.getNextEntry()) != null) {
                String name = entry.getName();
                if (name == null || name.contains("__MACOSX") || name.endsWith(".DS_Store")) {
                    zis.closeEntry();
                    continue;
                }

                // Normalize slashes
                name = name.replace('\\', '/');
                while (name.startsWith("/")) name = name.substring(1);
                if (name.isEmpty()) {
                    zis.closeEntry();
                    continue;
                }

                String[] parts = name.split("/");
                Uri currentDirUri = rootDocUri;

                // Navigate or create intermediate directories
                for (int i = 0; i < parts.length - 1; i++) {
                    String seg = parts[i].trim();
                    if (seg.isEmpty() || seg.equals(".")) continue;
                    Uri subDir = findOrCreateSubDir(treeUri, currentDirUri, seg);
                    if (subDir != null) {
                        currentDirUri = subDir;
                    }
                }

                // If entry itself is a directory
                if (entry.isDirectory()) {
                    String lastSeg = parts[parts.length - 1].trim();
                    if (!lastSeg.isEmpty() && !lastSeg.equals(".")) {
                        findOrCreateSubDir(treeUri, currentDirUri, lastSeg);
                    }
                    zis.closeEntry();
                    continue;
                }

                // Entry is a file
                String fileName = parts[parts.length - 1].trim();
                if (!fileName.isEmpty()) {
                    Uri fileUri = findOrCreateFile(treeUri, currentDirUri, "application/octet-stream", fileName);
                    if (fileUri != null) {
                        try (OutputStream out = getContentResolver().openOutputStream(fileUri, "wt")) {
                            int len;
                            while ((len = zis.read(buffer)) > 0) {
                                out.write(buffer, 0, len);
                            }
                            out.flush();
                        }
                        if (!deployedUrisList.contains(fileUri.toString())) {
                            deployedUrisList.add(fileUri.toString());
                        }
                        count++;
                        sendTerminalLog("INJECT", "Extracted: " + fileName, "ok");
                    }
                }
                zis.closeEntry();
            }
            sendTerminalLog("UNZIP", "Archive extraction complete: " + count + " files deployed.", "ok");
            return count > 0;
        } catch (Exception e) {
            Log.e(TAG, "unzipToDocumentTree error: ", e);
            sendTerminalLog("ERR", "SAF Unzip error: " + e.getMessage(), "err");
            return false;
        }
    }

    private boolean unzipToDirectory(File zipFile, File destDir) {
        if (zipFile == null || !zipFile.exists() || destDir == null) return false;
        if (!destDir.exists()) destDir.mkdirs();
        try (ZipInputStream zis = new ZipInputStream(new BufferedInputStream(new FileInputStream(zipFile)))) {
            ZipEntry entry;
            byte[] buffer = new byte[8192];
            String destCanonical = destDir.getCanonicalPath();
            int count = 0;
            while ((entry = zis.getNextEntry()) != null) {
                String name = entry.getName();
                if (name == null || name.contains("__MACOSX") || name.endsWith(".DS_Store")) {
                    zis.closeEntry();
                    continue;
                }
                name = name.replace('\\', '/');
                while (name.startsWith("/")) name = name.substring(1);
                if (name.isEmpty()) {
                    zis.closeEntry();
                    continue;
                }
                if (name.startsWith("com.tencent.ig/")) {
                    name = name.substring("com.tencent.ig/".length());
                    if (name.isEmpty()) {
                        zis.closeEntry();
                        continue;
                    }
                }

                File outFile = new File(destDir, name);
                if (!outFile.getCanonicalPath().startsWith(destCanonical)) {
                    zis.closeEntry();
                    continue; // Prevent Zip Slip
                }
                if (entry.isDirectory()) {
                    outFile.mkdirs();
                    if (!deployedDirsList.contains(outFile.getAbsolutePath())) {
                        deployedDirsList.add(0, outFile.getAbsolutePath());
                    }
                    sendTerminalLog("DIR", "[DIR] " + outFile.getAbsolutePath(), "info");
                } else {
                    File parent = outFile.getParentFile();
                    if (parent != null && !parent.exists()) {
                        parent.mkdirs();
                        if (!deployedDirsList.contains(parent.getAbsolutePath())) {
                            deployedDirsList.add(0, parent.getAbsolutePath());
                        }
                    }
                    if (outFile.exists()) {
                        try {
                            outFile.setWritable(true, false);
                            outFile.delete();
                        } catch (Exception ignored) {}
                    }
                    long bytesWritten = 0;
                    try (FileOutputStream fos = new FileOutputStream(outFile)) {
                        int len;
                        while ((len = zis.read(buffer)) > 0) {
                            fos.write(buffer, 0, len);
                            bytesWritten += len;
                        }
                        fos.flush();
                        try {
                            outFile.setReadable(true, false);
                            outFile.setWritable(false, false);
                            Runtime.getRuntime().exec(new String[]{"chmod", "444", outFile.getAbsolutePath()});
                        } catch (Exception ignored) {}
                        deployedFilesList.add(outFile.getAbsolutePath());
                        count++;
                        sendTerminalLog("SAVED", outFile.getAbsolutePath() + " (" + (bytesWritten / 1024) + " KB)", "ok");
                    } catch (Exception writeEx) {
                        Log.e(TAG, "Write error: " + outFile.getAbsolutePath(), writeEx);
                        sendTerminalLog("ERR", "Failed saving: " + outFile.getAbsolutePath() + " -> " + writeEx.getMessage(), "err");
                        // Show visible UI error for write failures
                        final String writeErrMsg = "Write failed: " + outFile.getName() + "\n" + writeEx.getMessage();
                        mainHandler.post(() -> notifyError(writeErrMsg));
                    }
                }
                zis.closeEntry();
            }
            sendTerminalLog("UNZIP", "Folder extraction complete: " + count + " files deployed directly to " + destDir.getAbsolutePath(), "ok");
            return count > 0;
        } catch (Exception e) {
            Log.e(TAG, "unzipToDirectory failed: ", e);
            sendTerminalLog("ERR", "Direct Unzip error: " + e.getMessage(), "err");
            // Show visible UI error alert
            final String unzipErrMsg = "Extraction failed: " + e.getMessage();
            mainHandler.post(() -> notifyError(unzipErrMsg));
            return false;
        }
    }

    // =========================================================================
    // HELPER FUNCTIONS
    // =========================================================================
    private String getDetectedGamePackage() {
        for (String pkg : TARGET_PACKAGES) {
            File paksDir = new File(
                    Environment.getExternalStorageDirectory(),
                    "Android/data/" + pkg + "/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks"
            );
            if (paksDir.exists()) {
                return pkg;
            }
        }
        return TARGET_PACKAGES[0]; // "com.tencent.ig"
    }

    private boolean isVpnActive() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Network activeNetwork = cm.getActiveNetwork();
                if (activeNetwork != null) {
                    NetworkCapabilities caps = cm.getNetworkCapabilities(activeNetwork);
                    if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                        return true;
                    }
                }
            }
        } catch (Exception ignored) {}
        return false;
    }

    private void deleteRecursive(File fileOrDir) {
        if (fileOrDir == null || !fileOrDir.exists()) return;
        if (fileOrDir.isDirectory()) {
            File[] children = fileOrDir.listFiles();
            if (children != null) {
                for (File child : children) {
                    deleteRecursive(child);
                }
            }
        }
        fileOrDir.setWritable(true, false);
        fileOrDir.delete();
    }

    private boolean isDirWritable(File dir) {
        if (dir == null) return false;
        if (!dir.exists()) {
            try {
                if (!dir.mkdirs()) {
                    File parent = dir.getParentFile();
                    if (parent == null || !parent.canWrite()) return false;
                }
            } catch (Exception ignored) {
                return false;
            }
        }
        if (!dir.isDirectory()) return false;
        if (dir.canWrite()) return true;
        // Test writability by creating a temporary file (solves Android emulated storage false negatives)
        try {
            File testFile = new File(dir, ".perm_test_" + System.currentTimeMillis());
            if (testFile.createNewFile()) {
                testFile.delete();
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    public static final String TARGET_BASE_PATH = "/storage/emulated/0/Android/data/com.tencent.ig";

    private File resolveTargetPaksDirectory() {
        // Try primary fixed path first
        File primary = new File(TARGET_BASE_PATH);
        try {
            if (!primary.exists()) {
                primary.mkdirs();
            }
            if (primary.exists() && primary.isDirectory()) {
                return primary;
            }
        } catch (Exception ignored) {}

        // Fallback 1: Environment-based path
        File ext = new File(Environment.getExternalStorageDirectory(), "Android/data/com.tencent.ig");
        try {
            if (!ext.exists()) {
                ext.mkdirs();
            }
            if (ext.exists() && ext.isDirectory()) {
                return ext;
            }
        } catch (Exception ignored) {}

        // Fallback 2: User-selected folder via SAF (saved in SharedPreferences)
        try {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String savedPath = prefs.getString("manual_target_path", "");
            if (savedPath != null && !savedPath.isEmpty()) {
                File manualDir = new File(savedPath);
                if (!manualDir.exists()) manualDir.mkdirs();
                if (manualDir.exists() && manualDir.isDirectory()) {
                    sendTerminalLog("CONFIG", "Using manually selected folder: " + savedPath, "ok");
                    return manualDir;
                }
            }
        } catch (Exception ignored) {}

        // All failed — return null to signal that SAF picker is needed
        return null;
    }

    private boolean isZipFile(File file) {
        if (!file.exists() || file.length() < 4) return false;
        try (InputStream is = new FileInputStream(file)) {
            byte[] header = new byte[4];
            int read = is.read(header);
            return read == 4 && header[0] == 0x50 && header[1] == 0x4B;
        } catch (Exception e) {
            return false;
        }
    }

    private void copyFile(File src, File dst) throws Exception {
        boolean directSuccess = false;
        try (InputStream in = new FileInputStream(src);
             OutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            out.flush();
            directSuccess = true;
        } catch (Exception ex) {
            Log.w(TAG, "Direct FileOutputStream failed, trying SAF URI fallback: " + ex.getMessage());
        }

        if (!directSuccess) {
            // Storage Access Framework (SAF) Fallback for Android 11/12/13/14 Scoped Storage
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String manualUriStr = prefs.getString("manual_target_uri", "");
            if (!manualUriStr.isEmpty()) {
                try {
                    Uri treeUri = Uri.parse(manualUriStr);
                    Uri docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri));
                    Uri newFileUri = DocumentsContract.createDocument(getContentResolver(), docUri, "application/octet-stream", dst.getName());
                    if (newFileUri != null) {
                        try (InputStream in = new FileInputStream(src);
                             OutputStream out = getContentResolver().openOutputStream(newFileUri)) {
                            byte[] buf = new byte[8192];
                            int len;
                            while ((len = in.read(buf)) > 0) {
                                out.write(buf, 0, len);
                            }
                            out.flush();
                        }
                    }
                } catch (Exception safEx) {
                    Log.e(TAG, "SAF copy fallback also failed: ", safEx);
                    throw safEx;
                }
            } else {
                throw new Exception("Write access denied. Please authorize folder access.");
            }
        }
    }

    // =========================================================================
    // UI NOTIFICATIONS VIA JAVASCRIPT EVALUATION
    // =========================================================================
    private void sendTerminalLog(String tag, String message, String type) {
        mainHandler.post(() -> {
            String script = String.format(
                    "if(window.onNativeLog){window.onNativeLog('%s', '%s', '%s');}",
                    escapeJs(tag), escapeJs(message), escapeJs(type)
            );
            webView.evaluateJavascript(script, null);
        });
    }

    private void notifyConnected(long remainingSeconds) {
        mainHandler.post(() -> {
            String script = String.format(
                    "if(window.onNativeConnected){window.onNativeConnected(%d);}",
                    remainingSeconds
            );
            webView.evaluateJavascript(script, null);
        });
    }

    private void notifyDisconnected() {
        mainHandler.post(() -> {
            String script = "if(window.onNativeDisconnected){window.onNativeDisconnected();}";
            webView.evaluateJavascript(script, null);
        });
    }

    private void notifyAddressNotFound(final String msg) {
        mainHandler.post(() -> {
            if (webView != null) {
                String script = "if (window.onAddressNotFound) { window.onAddressNotFound('"
                        + escapeJs(msg) + "'); } else { alert('" + escapeJs(msg) + "'); }";
                webView.evaluateJavascript(script, null);
            }
        });
    }

    private void notifyDeviceBanned(String reason) {
        mainHandler.post(() -> {
            String script = String.format(
                    "if(window.onNativeBanned){window.onNativeBanned('%s');}else if(window.onNativeKeyRevoked){window.onNativeKeyRevoked('%s');}",
                    escapeJs(reason), escapeJs(reason)
            );
            webView.evaluateJavascript(script, null);
        });
    }

    private void notifyKeyRevoked(String reason) {
        mainHandler.post(() -> {
            String script = String.format(
                    "if(window.onNativeKeyRevoked){window.onNativeKeyRevoked('%s');}",
                    escapeJs(reason)
            );
            webView.evaluateJavascript(script, null);
        });
    }

    private void notifyError(String errorMsg) {
        mainHandler.post(() -> {
            String script = String.format(
                    "if(window.onNativeError){window.onNativeError('%s');}",
                    escapeJs(errorMsg)
            );
            webView.evaluateJavascript(script, null);
        });
    }

    private String escapeJs(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "");
    }
}
