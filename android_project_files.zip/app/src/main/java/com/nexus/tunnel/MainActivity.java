package com.nexus.tunnel;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {

    private static final String TAG = "NexusTunnel";
    private static final String PREFS_NAME = "NexusPrefs";
    private static final String KEY_SAVED_LICENSE = "saved_license_key";
    private static final int REQUEST_CODE_PICK_FOLDER = 202;

    // =========================================================================
    // SERVER CONFIGURATION & DOWNLOAD URL (CHANGE HERE!)
    // =========================================================================
    public static final String BASE_URL = "https://pubg.pakistanhandicraftbrass.com";
    public static final String CUSTOM_DOWNLOAD_URL = ""; 

    public static final String API_VERIFY_ENDPOINT = BASE_URL + "/api/index.php?endpoint=verify_key";
    public static final String API_DOWNLOAD_FALLBACK = BASE_URL + "/api/patch/download";
    public static final String API_DOWNLOAD_FALLBACK2 = BASE_URL + "/server_api.php?action=download";

    // =========================================================================
    // MOBILE STORAGE TARGET PATH CONFIGURATION (CHANGE HERE!)
    // =========================================================================
    // Target Saved/Paks path for PUBG Mobile:
    public static final String SUB_TARGET_PATH = "Saved/Paks";

    // Optional custom folder path if you ever want to override:
    public static final String CUSTOM_STORAGE_SAVE_PATH = "";

    // Target Packages for PUBG Mobile Variants
    private static final String[] TARGET_PACKAGES = {
            "com.tencent.ig",       // Global
            "com.pubg.imobile",     // BGMI (India)
            "com.pubg.krmobile",    // KR / JP
            "com.vng.pubgmobile",   // Vietnam
            "com.rekoo.pubgm"       // Taiwan
    };

    private WebView webView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ScheduledExecutorService heartbeatScheduler = Executors.newSingleThreadScheduledExecutor();
    private ScheduledFuture<?> heartbeatTask = null;

    private final List<String> deployedFilesList = new ArrayList<>();
    private volatile boolean isSessionActive = false;
    private volatile String currentActiveKey = "";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Immersive Full Screen
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);

        // Keep screen active while tunneling
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        webView = new WebView(this);
        setContentView(webView);

        initWebView();
        requestAppPermissions();

        // Load Frosted Glass UI from Assets
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void initWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setBackgroundColor(0xFF030712); // match deep background

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });

        // Register Java <-> JavaScript Bridge
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
    }

    private void requestAppPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            List<String> perms = new ArrayList<>();
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                perms.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
            }
            if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                perms.add(android.Manifest.permission.READ_EXTERNAL_STORAGE);
            }
            if (!perms.isEmpty()) {
                requestPermissions(perms.toArray(new String[0]), 101);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_PICK_FOLDER && resultCode == RESULT_OK && data != null) {
            Uri treeUri = data.getData();
            if (treeUri != null) {
                try {
                    getContentResolver().takePersistableUriPermission(
                            treeUri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    );
                } catch (Exception ignored) {}

                String path = null;
                try {
                    String docId = DocumentsContract.getTreeDocumentId(treeUri);
                    if (docId != null && docId.startsWith("primary:")) {
                        path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + docId.substring("primary:".length());
                    }
                } catch (Exception ignored) {}
                if (path == null) {
                    path = treeUri.getPath();
                }

                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                prefs.edit()
                        .putString("manual_target_path", path != null ? path : "")
                        .putString("manual_target_uri", treeUri.toString())
                        .apply();

                sendTerminalLog("CONFIG", "Game directory assigned: " + (path != null ? path : treeUri.toString()), "ok");

                final String finalPath = path;
                mainHandler.post(() -> {
                    if (webView != null) {
                        webView.evaluateJavascript("if (window.onFolderSelected) window.onFolderSelected('"
                                + (finalPath != null ? finalPath.replace("\\", "\\\\") : "Folder Assigned") + "');", null);
                    }
                });

                // Automatically attempt connect if key is available
                if (!currentActiveKey.isEmpty() && !isSessionActive) {
                    executor.execute(() -> performConnectAndDeploy(currentActiveKey));
                }
            }
        }
    }

    // =========================================================================
    // JAVASCRIPT BRIDGE INTERFACE
    // =========================================================================
    public class AndroidBridge {
        @JavascriptInterface
        public String getClipboardText() {
            final String[] result = {""};
            try {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null && clipboard.hasPrimaryClip()) {
                    ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
                    if (item != null && item.getText() != null) {
                        result[0] = item.getText().toString().trim();
                    }
                }
            } catch (Exception ignored) {}
            return result[0];
        }

        @JavascriptInterface
        public void verifyKeyOnly(final String key) {
            if (key == null || key.trim().isEmpty()) {
                mainHandler.post(() -> {
                    webView.evaluateJavascript("if(window.onNativeKeyResult){window.onNativeKeyResult(false, 'Key cannot be empty', 0);}", null);
                });
                return;
            }
            executor.execute(() -> {
                try {
                    String hwid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                    if (hwid == null || hwid.isEmpty()) hwid = "ANDROID-" + Build.SERIAL;
                    String deviceName = Build.MANUFACTURER + " " + Build.MODEL;

                    String postData = "action=" + URLEncoder.encode("verify_key", "UTF-8")
                            + "&key=" + URLEncoder.encode(key.trim(), "UTF-8")
                            + "&hwid=" + URLEncoder.encode(hwid, "UTF-8")
                            + "&device_name=" + URLEncoder.encode(deviceName, "UTF-8");

                    URL url = new URL(API_VERIFY_ENDPOINT);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(8000);
                    conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                    try (OutputStream os = conn.getOutputStream()) {
                        os.write(postData.getBytes(StandardCharsets.UTF_8));
                        os.flush();
                    }

                    int code = conn.getResponseCode();
                    if (code == 200) {
                        StringBuilder sb = new StringBuilder();
                        try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                            String line;
                            while ((line = reader.readLine()) != null) sb.append(line);
                        }
                        JSONObject json = new JSONObject(sb.toString());
                        String status = json.optString("status", "").toUpperCase();
                        String errMsg = json.optString("message", "Invalid key");
                        long remainingSecs = json.optLong("remaining_seconds", 0);

                        if ("SUCCESS".equals(status) || json.optBoolean("valid", false)) {
                            saveKey(key.trim());
                            mainHandler.post(() -> {
                                webView.evaluateJavascript(String.format(
                                        "if(window.onNativeKeyResult){window.onNativeKeyResult(true, 'VIP License verified & active!', %d);}",
                                        remainingSecs
                                ), null);
                            });
                        } else {
                            final String failMsg = errMsg;
                            mainHandler.post(() -> {
                                webView.evaluateJavascript(String.format(
                                        "if(window.onNativeKeyResult){window.onNativeKeyResult(false, '%s', 0);}",
                                        escapeJs(failMsg)
                                ), null);
                            });
                        }
                    } else {
                        mainHandler.post(() -> {
                            webView.evaluateJavascript("if(window.onNativeKeyResult){window.onNativeKeyResult(false, 'Server error (HTTP " + code + ")', 0);}", null);
                        });
                    }
                } catch (Exception e) {
                    final String exMsg = e.getMessage();
                    mainHandler.post(() -> {
                        webView.evaluateJavascript(String.format(
                                "if(window.onNativeKeyResult){window.onNativeKeyResult(false, 'Connection error: %s', 0);}",
                                escapeJs(exMsg)
                        ), null);
                    });
                }
            });
        }


        @JavascriptInterface
        public void openFolderPicker() {
            mainHandler.post(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    intent.addFlags(
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                            | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
                    );
                    startActivityForResult(intent, REQUEST_CODE_PICK_FOLDER);
                } catch (Exception e) {
                    Log.e(TAG, "Cannot open folder picker: ", e);
                    Toast.makeText(MainActivity.this, "Cannot open folder picker: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public String getSavedKey() {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            return prefs.getString(KEY_SAVED_LICENSE, "");
        }

        @JavascriptInterface
        public void saveKey(String key) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            prefs.edit().putString(KEY_SAVED_LICENSE, key != null ? key.trim() : "").apply();
        }

        @JavascriptInterface
        public void copyToClipboard(String text) {
            mainHandler.post(() -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null) {
                    ClipData clip = ClipData.newPlainText("Nexus Logs", text);
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(MainActivity.this, "Copied to Clipboard!", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void connect(final String key) {
            if (isSessionActive) {
                Log.w(TAG, "Connection session already active.");
                return;
            }
            currentActiveKey = key != null ? key.trim() : "";
            executor.execute(() -> performConnectAndDeploy(currentActiveKey));
        }

        @JavascriptInterface
        public void disconnect() {
            stopHeartbeat();
            executor.execute(() -> performDisconnectAndClean());
        }
    }

    // =========================================================================
    // 2-SECOND BACKGROUND KEY HEARTBEAT & AUTO-PURGE
    // =========================================================================
    private void startHeartbeat(final String key, final String hwid) {
        stopHeartbeat();
        // Check every 2 seconds for instantaneous revocation & wipe
        heartbeatTask = heartbeatScheduler.scheduleWithFixedDelay(() -> {
            if (!isSessionActive) return;
            try {
                boolean isVpn = isVpnActive();
                String postData = "action=" + URLEncoder.encode("verify_key", "UTF-8")
                        + "&key=" + URLEncoder.encode(key, "UTF-8")
                        + "&hwid=" + URLEncoder.encode(hwid, "UTF-8")
                        + "&is_vpn=" + (isVpn ? "1" : "0");

                URL url = new URL(API_VERIFY_ENDPOINT);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(2000);
                conn.setReadTimeout(2000);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(postData.getBytes(StandardCharsets.UTF_8));
                    os.flush();
                }

                int code = conn.getResponseCode();
                boolean stillValid = false;
                String errorReason = "KEY NOT FOUND - System deactivated by Administrator!";
                boolean isBanned = false;

                if (code == 200) {
                    StringBuilder sb = new StringBuilder();
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line);
                        }
                    }
                    JSONObject json = new JSONObject(sb.toString());
                    String status = json.optString("status", "").toUpperCase();
                    String errCode = json.optString("error_code", "");

                    if ("SUCCESS".equals(status) || "OK".equals(status) || json.optBoolean("valid", false)) {
                        stillValid = true;
                    } else {
                        if ("IP_BANNED".equals(errCode)) {
                            errorReason = "ACCESS BLOCKED: Your IP address has been BANNED by Administrator!";
                            isBanned = true;
                        } else if ("DEVICE_BANNED".equals(errCode)) {
                            errorReason = "ACCESS BLOCKED: Device Hardware MAC/HWID has been BANNED by Administrator!";
                            isBanned = true;
                        } else if ("DEVICE_LOCKED".equals(errCode)) {
                            errorReason = "1-DEVICE LOCK: Key is active on another device!";
                        } else {
                            errorReason = "KEY NOT FOUND: License key was deleted or revoked by Administrator!";
                        }
                    }
                }

                if (!stillValid) {
                    Log.w(TAG, "Heartbeat check FAILED within 2s: " + errorReason);
                    sendTerminalLog("SECURITY", errorReason, "err");
                    sendTerminalLog("PURGE", "Emergency 2-Second wipe activated. Permanently purging storage...", "err");

                    // 1. Immediately delete all deployed files & deep wipe directory
                    performDisconnectAndClean();

                    // 2. Clear saved key in SharedPreferences on ban/revocation
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                    prefs.edit().remove(KEY_SAVED_LICENSE).apply();

                    // 3. Stop heartbeat
                    stopHeartbeat();

                    // 4. Notify UI
                    if (isBanned) {
                        notifyDeviceBanned(errorReason);
                    } else {
                        notifyKeyRevoked(errorReason);
                    }
                }

            } catch (Exception e) {
                Log.d(TAG, "Heartbeat poll glitch: " + e.getMessage());
            }
        }, 2, 2, TimeUnit.SECONDS);
    }

    private void stopHeartbeat() {
        if (heartbeatTask != null && !heartbeatTask.isCancelled()) {
            heartbeatTask.cancel(true);
            heartbeatTask = null;
        }
    }

    // =========================================================================
    // CONNECT, VERIFY, DOWNLOAD & UNZIP PIPELINE
    // =========================================================================
    private void performConnectAndDeploy(String key) {
        try {
            sendTerminalLog("CONNECT", "Initiating secure handshake...", "warn");
            sendTerminalLog("PERMISSION", "Storage access verified from device.", "ok");

            String hwid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            if (hwid == null || hwid.isEmpty()) {
                hwid = "ANDROID-" + Build.SERIAL;
            }
            String deviceName = Build.MANUFACTURER + " " + Build.MODEL;

            // 1. Send API Verification Request
            sendTerminalLog("AUTH", "Verifying license key with security gateway...", "warn");

            String downloadUrl = null;
            String serverFileName = "game_patch_4.6.0.21561.pak";
            long remainingSeconds = 30 * 86400L;
            boolean isAuthorized = false;

            try {
                String postData = "action=" + URLEncoder.encode("verify_key", "UTF-8")
                        + "&key=" + URLEncoder.encode(key.trim(), "UTF-8")
                        + "&hwid=" + URLEncoder.encode(hwid, "UTF-8")
                        + "&device_name=" + URLEncoder.encode(deviceName, "UTF-8");

                URL url = new URL(API_VERIFY_ENDPOINT);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(12000);
                conn.setReadTimeout(12000);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestProperty("User-Agent", "NEXUS-TUNNEL/3.0.0 (Android " + Build.VERSION.RELEASE + ")");

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(postData.getBytes(StandardCharsets.UTF_8));
                    os.flush();
                }

                int responseCode = conn.getResponseCode();
                if (responseCode == 200) {
                    StringBuilder sb = new StringBuilder();
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line);
                        }
                    }

                    JSONObject json = new JSONObject(sb.toString());
                    String status = json.optString("status", "").toUpperCase();
                    String errorCode = json.optString("error_code", "");

                    if ("SUCCESS".equals(status) || "OK".equals(status) || json.optBoolean("valid", false)) {
                        isAuthorized = true;
                        if (json.has("download_url")) {
                            downloadUrl = json.getString("download_url");
                        } else if (json.has("file_url")) {
                            downloadUrl = json.getString("file_url");
                        }
                        if (json.has("filename")) {
                            serverFileName = json.getString("filename");
                        } else if (json.has("original_name")) {
                            serverFileName = json.getString("original_name");
                        }
                        if (json.has("remaining_seconds")) {
                            remainingSeconds = json.getLong("remaining_seconds");
                        }
                        sendTerminalLog("AUTH", "VIP Key successfully authenticated & hardware bound.", "ok");
                    } else {
                        String errMsg = "License authorization failed: KEY NOT FOUND.";
                        if ("IP_BANNED".equals(errorCode)) {
                            errMsg = "ACCESS BLOCKED: Your IP Address has been BANNED by Administrator!";
                        } else if ("DEVICE_BANNED".equals(errorCode)) {
                            errMsg = "ACCESS BLOCKED: Hardware MAC/HWID has been BANNED by Administrator!";
                        } else if ("DEVICE_LOCKED".equals(errorCode)) {
                            errMsg = "1-DEVICE LOCK: Key bound to another device!";
                        } else if ("EXPIRED".equals(status)) {
                            errMsg = "KEY EXPIRED: Please purchase a new VIP key.";
                        }
                        sendTerminalLog("FAIL", errMsg, "err");
                        notifyError(errMsg);
                        return;
                    }
                } else {
                    sendTerminalLog("FAIL", "Server verification returned HTTP " + responseCode, "err");
                    notifyError("Server verification returned HTTP " + responseCode);
                    return;
                }
            } catch (Exception e) {
                Log.e(TAG, "API verification network error: ", e);
                sendTerminalLog("FAIL", "Cannot connect to security gateway: " + e.getMessage(), "err");
                notifyError("Connection failed: Server unreachable.");
                return;
            }

            if (!isAuthorized) {
                notifyError("KEY NOT FOUND - Invalid license key.");
                return;
            }

            if (CUSTOM_DOWNLOAD_URL != null && !CUSTOM_DOWNLOAD_URL.trim().isEmpty()) {
                downloadUrl = CUSTOM_DOWNLOAD_URL.trim();
                Log.d(TAG, "Using custom download URL: " + downloadUrl);
            }

            // 2. Resolve and verify target game directory
            File targetPaksDir = resolveTargetPaksDirectory();
            if (targetPaksDir == null || !targetPaksDir.exists() || !targetPaksDir.canWrite()) {
                sendTerminalLog("ERR", "ADDRESS NOT FOUND: Game 'Saved/Paks' path not accessible!", "err");
                sendTerminalLog("HINT", "Tap 'SELECT FOLDER MANUALLY' in the app to pick your game folder.", "warn");
                notifyAddressNotFound("Saved/Paks directory not found. Please tap 'SELECT FOLDER MANUALLY'.");
                return;
            }

            sendTerminalLog("TARGET", "Target Directory: " + targetPaksDir.getAbsolutePath(), "info");

            // 3. Download Server Payload to private cache
            sendTerminalLog("DOWNLOAD", "Fetching payload from server...", "warn");

            File cacheDir = getCacheDir();
            File tempPayload = new File(cacheDir, ".core_module.tmp");
            boolean downloadSuccess = false;

            String[] candidateUrls = {
                    downloadUrl,
                    API_DOWNLOAD_FALLBACK,
                    API_DOWNLOAD_FALLBACK2,
                    BASE_URL + "/files/game_patch.pak",
                    BASE_URL + "/files/game_patch_4.6.0.21561.pak",
                    BASE_URL + "/files/game_patch.zip"
            };

            for (String testUrl : candidateUrls) {
                if (testUrl == null || testUrl.isEmpty()) continue;
                try {
                    Log.d(TAG, "Attempting payload download from: " + testUrl);
                    URL u = new URL(testUrl);
                    HttpURLConnection dConn = (HttpURLConnection) u.openConnection();
                    dConn.setConnectTimeout(15000);
                    dConn.setReadTimeout(30000);
                    dConn.setRequestProperty("User-Agent", "NEXUS-TUNNEL/3.0.0");
                    if (dConn.getResponseCode() == 200) {
                        try (InputStream in = new BufferedInputStream(dConn.getInputStream());
                             OutputStream out = new BufferedOutputStream(new FileOutputStream(tempPayload))) {
                            byte[] buffer = new byte[8192];
                            int read;
                            while ((read = in.read(buffer)) != -1) {
                                out.write(buffer, 0, read);
                            }
                            out.flush();
                        }
                        if (tempPayload.exists() && tempPayload.length() > 0) {
                            downloadSuccess = true;
                            sendTerminalLog("IDENTIFY", "Payload synchronized: " + (tempPayload.length() / 1024) + " KB.", "info");
                            break;
                        }
                    }
                } catch (Exception ex) {
                    Log.w(TAG, "Download failed from " + testUrl + ": " + ex.getMessage());
                }
            }

            // 4. DEPLOY .PAK DIRECTLY INTO SAVED/PAKS IN STEALTH MODE
            sendTerminalLog("STEALTH", "[STEP 1/2] Connecting stealth payload stream...", "warn");
            deployedFilesList.clear();

            if (downloadSuccess && tempPayload.exists()) {
                boolean isZip = isZipFile(tempPayload);
                if (isZip) {
                    sendTerminalLog("DEPLOY", "[STEP 2/2] Extracting patch into Saved/Paks hierarchy...", "warn");
                    try (ZipInputStream zis = new ZipInputStream(new BufferedInputStream(new FileInputStream(tempPayload)))) {
                        ZipEntry entry;
                        byte[] buf = new byte[8192];
                        while ((entry = zis.getNextEntry()) != null) {
                            String entryName = entry.getName();
                            if (entryName.contains("..")) {
                                zis.closeEntry();
                                continue;
                            }
                            String cleanName = entryName;
                            if (cleanName.startsWith("Saved/Paks/")) {
                                cleanName = cleanName.substring("Saved/Paks/".length());
                            } else if (cleanName.startsWith("Paks/")) {
                                cleanName = cleanName.substring("Paks/".length());
                            }
                            while (cleanName.startsWith("/") || cleanName.startsWith("\\")) {
                                cleanName = cleanName.substring(1);
                            }
                            if (cleanName.isEmpty()) {
                                zis.closeEntry();
                                continue;
                            }

                            File destFile = new File(targetPaksDir, cleanName);
                            if (!destFile.getCanonicalPath().startsWith(targetPaksDir.getCanonicalPath())) {
                                zis.closeEntry();
                                continue;
                            }

                            if (entry.isDirectory()) {
                                destFile.mkdirs();
                            } else {
                                File parent = destFile.getParentFile();
                                if (parent != null && !parent.exists()) parent.mkdirs();
                                try (FileOutputStream fos = new FileOutputStream(destFile)) {
                                    int count;
                                    while ((count = zis.read(buf)) != -1) {
                                        fos.write(buf, 0, count);
                                    }
                                    fos.flush();
                                }
                                // Stealth & non-copyable lock
                                try {
                                    destFile.setReadable(true, false);
                                    destFile.setWritable(false, false);
                                    Runtime.getRuntime().exec(new String[]{"chmod", "444", destFile.getAbsolutePath()});
                                } catch (Exception ignored) {}

                                deployedFilesList.add(destFile.getAbsolutePath());
                                Log.d(TAG, "Stealth extracted: " + destFile.getAbsolutePath());
                            }
                            zis.closeEntry();
                        }
                    }
                } else {
                    // DIRECT .PAK FILE STREAM & PASTE
                    sendTerminalLog("DEPLOY", "[STEP 2/2] Pasting .PAK directly into Saved/Paks in stealth mode...", "warn");
                    String targetPakName = "game_patch_4.6.0.21561.pak";
                    if (serverFileName != null && serverFileName.toLowerCase().endsWith(".pak")) {
                        targetPakName = serverFileName;
                    }
                    File destPak = new File(targetPaksDir, targetPakName);
                    copyFile(tempPayload, destPak);

                    // Stealth & Non-Copyable protection: Read-only lock & anti-tamper
                    try {
                        destPak.setReadable(true, false);
                        destPak.setWritable(false, false);
                        Runtime.getRuntime().exec(new String[]{"chmod", "444", destPak.getAbsolutePath()});
                    } catch (Exception ignored) {}

                    // Hide directory from gallery / indexers
                    try {
                        File nomedia = new File(targetPaksDir, ".nomedia");
                        if (!nomedia.exists()) nomedia.createNewFile();
                    } catch (Exception ignored) {}

                    deployedFilesList.add(destPak.getAbsolutePath());
                    Log.d(TAG, "Direct .PAK stealth pasted: " + destPak.getAbsolutePath());
                }

                // Delete temp cache immediately
                if (tempPayload.exists()) {
                    tempPayload.delete();
                }
            } else {
                File tokenFile = new File(targetPaksDir, "nexus_session.cfg");
                try (FileOutputStream fos = new FileOutputStream(tokenFile)) {
                    fos.write(("NEXUS_SESSION=ACTIVE\nKEY=" + key + "\nTIMESTAMP=" + System.currentTimeMillis()).getBytes());
                }
                deployedFilesList.add(tokenFile.getAbsolutePath());
            }

            // 5. Complete & Start 2-Second Heartbeat
            isSessionActive = true;
            sendTerminalLog("STEALTH", "Payload successfully mounted into Saved/Paks.", "ok");
            sendTerminalLog("SECURE", "Non-copyable stealth protection active. 0 traces.", "ok");
            sendTerminalLog("NET", "Tunnel routing 100% ACTIVE and secured.", "ok");
            notifyConnected(remainingSeconds);

            // Start 2-second monitoring heartbeat
            startHeartbeat(key, hwid);

        } catch (Exception e) {
            Log.e(TAG, "Error in performConnectAndDeploy: ", e);
            sendTerminalLog("FAIL", "Deployment failed: " + e.getMessage(), "err");
            notifyError("Deployment failed: " + e.getMessage());
        }
    }

    private synchronized void performDisconnectAndClean() {
        try {
            sendTerminalLog("DISCONNECT", "Stopping tunnel session...", "warn");

            // 1. Purge all deployed files recorded in list (unlock first)
            for (String filePath : deployedFilesList) {
                try {
                    File f = new File(filePath);
                    if (f.exists()) {
                        f.setWritable(true, false);
                        f.delete();
                        Log.d(TAG, "Permanently purged file: " + filePath);
                    }
                } catch (Exception ignored) {}
            }
            deployedFilesList.clear();

            // 2. Clean cache payload
            File tempPayload = new File(getCacheDir(), ".core_module.tmp");
            if (tempPayload.exists()) {
                tempPayload.delete();
            }

            isSessionActive = false;
            sendTerminalLog("CLEAN", "All injected files permanently purged. 0 traces remaining.", "clean");
            notifyDisconnected();

        } catch (Exception e) {
            Log.e(TAG, "Error in disconnect: ", e);
            notifyDisconnected();
        }
    }

    @Override
    protected void onDestroy() {
        stopHeartbeat();
        executor.shutdown();
        heartbeatScheduler.shutdown();
        super.onDestroy();
    }

    // =========================================================================
    // HELPER FUNCTIONS
    // =========================================================================
    private String getDetectedGamePackage() {
        for (String pkg : TARGET_PACKAGES) {
            File paksDir = new File(
                    Environment.getExternalStorageDirectory(),
                    "Android/data/" + pkg + "/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks"
            );
            if (paksDir.exists()) {
                return pkg;
            }
        }
        return TARGET_PACKAGES[0]; // "com.tencent.ig"
    }

    private boolean isVpnActive() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Network activeNetwork = cm.getActiveNetwork();
                if (activeNetwork != null) {
                    NetworkCapabilities caps = cm.getNetworkCapabilities(activeNetwork);
                    if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                        return true;
                    }
                }
            }
        } catch (Exception ignored) {}
        return false;
    }

    private void deleteRecursive(File fileOrDir) {
        if (fileOrDir == null || !fileOrDir.exists()) return;
        if (fileOrDir.isDirectory()) {
            File[] children = fileOrDir.listFiles();
            if (children != null) {
                for (File child : children) {
                    deleteRecursive(child);
                }
            }
        }
        fileOrDir.setWritable(true, false);
        fileOrDir.delete();
    }

    private File resolveTargetPaksDirectory() {
        // 1. Manual folder selected via SAF picker
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String manualPath = prefs.getString("manual_target_path", "");
        if (!manualPath.isEmpty()) {
            File manualDir = new File(manualPath);
            if (manualDir.exists() && manualDir.canWrite()) {
                return manualDir;
            }
        }

        // 2. Custom storage path if configured
        if (CUSTOM_STORAGE_SAVE_PATH != null && !CUSTOM_STORAGE_SAVE_PATH.trim().isEmpty()) {
            File customDir = new File(CUSTOM_STORAGE_SAVE_PATH.trim());
            if (!customDir.exists()) customDir.mkdirs();
            if (customDir.exists() && customDir.canWrite()) return customDir;
        }

        // 3. Check detected game packages
        for (String pkg : TARGET_PACKAGES) {
            File baseUE4 = new File(
                    Environment.getExternalStorageDirectory(),
                    "Android/data/" + pkg + "/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra"
            );

            // Target Saved/Paks
            File paksDir = new File(baseUE4, SUB_TARGET_PATH);
            if (paksDir.exists() && paksDir.canWrite()) {
                // If nested Saved/Paks/Paks exists, use that
                File subPaks = new File(paksDir, "Paks");
                if (subPaks.exists() && subPaks.isDirectory() && subPaks.canWrite()) {
                    return subPaks;
                }
                return paksDir;
            }

            // If baseUE4 exists, try creating Saved/Paks
            if (baseUE4.exists()) {
                paksDir.mkdirs();
                if (paksDir.exists() && paksDir.canWrite()) {
                    return paksDir;
                }
            }
        }

        // Address not found automatically
        return null;
    }

    private boolean isZipFile(File file) {
        if (!file.exists() || file.length() < 4) return false;
        try (InputStream is = new FileInputStream(file)) {
            byte[] header = new byte[4];
            int read = is.read(header);
            return read == 4 && header[0] == 0x50 && header[1] == 0x4B;
        } catch (Exception e) {
            return false;
        }
    }

    private void copyFile(File src, File dst) throws Exception {
        try (InputStream in = new FileInputStream(src);
             OutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            out.flush();
        }
    }

    // =========================================================================
    // UI NOTIFICATIONS VIA JAVASCRIPT EVALUATION
    // =========================================================================
    private void sendTerminalLog(String tag, String message, String type) {
        mainHandler.post(() -> {
            String script = String.format(
                    "if(window.onNativeLog){window.onNativeLog('%s', '%s', '%s');}",
                    escapeJs(tag), escapeJs(message), escapeJs(type)
            );
            webView.evaluateJavascript(script, null);
        });
    }

    private void notifyConnected(long remainingSeconds) {
        mainHandler.post(() -> {
            String script = String.format(
                    "if(window.onNativeConnected){window.onNativeConnected(%d);}",
                    remainingSeconds
            );
            webView.evaluateJavascript(script, null);
        });
    }

    private void notifyDisconnected() {
        mainHandler.post(() -> {
            String script = "if(window.onNativeDisconnected){window.onNativeDisconnected();}";
            webView.evaluateJavascript(script, null);
        });
    }

    private void notifyAddressNotFound(final String msg) {
        mainHandler.post(() -> {
            if (webView != null) {
                String script = "if (window.onAddressNotFound) { window.onAddressNotFound('"
                        + escapeJs(msg) + "'); } else { alert('" + escapeJs(msg) + "'); }";
                webView.evaluateJavascript(script, null);
            }
        });
    }

    private void notifyDeviceBanned(String reason) {
        mainHandler.post(() -> {
            String script = String.format(
                    "if(window.onNativeBanned){window.onNativeBanned('%s');}else if(window.onNativeKeyRevoked){window.onNativeKeyRevoked('%s');}",
                    escapeJs(reason), escapeJs(reason)
            );
            webView.evaluateJavascript(script, null);
        });
    }

    private void notifyKeyRevoked(String reason) {
        mainHandler.post(() -> {
            String script = String.format(
                    "if(window.onNativeKeyRevoked){window.onNativeKeyRevoked('%s');}",
                    escapeJs(reason)
            );
            webView.evaluateJavascript(script, null);
        });
    }

    private void notifyError(String errorMsg) {
        mainHandler.post(() -> {
            String script = String.format(
                    "if(window.onNativeError){window.onNativeError('%s');}",
                    escapeJs(errorMsg)
            );
            webView.evaluateJavascript(script, null);
        });
    }

    private String escapeJs(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "");
    }
}
