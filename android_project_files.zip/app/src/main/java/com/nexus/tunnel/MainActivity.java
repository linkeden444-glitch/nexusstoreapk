package com.nexus.tunnel;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {

    private static final String TAG = "NexusTunnel";
    private static final String PREFS_NAME = "NexusTunnelPrefs";
    private static final String KEY_SAVED_LICENSE = "nexus_saved_vip_key";
    private static final int REQUEST_CODE_PICK_FOLDER = 1001;
    private static final int REQUEST_CODE_VPN = 303;

    // Production Gateway Configuration (Live Domain: pubg.pakistanhandicraftbrass.com)
    public static final String BASE_URL = "https://pubg.pakistanhandicraftbrass.com";
    public static final String API_VERIFY_ENDPOINT = BASE_URL + "/server_api.php";
    public static final String API_DOWNLOAD_FALLBACK = BASE_URL + "/server_api.php?action=download";
    public static final String API_DOWNLOAD_FALLBACK2 = BASE_URL + "/files/game_patch.pak";
    public static final String CUSTOM_DOWNLOAD_URL = "";

    // =========================================================================
    // MOBILE STORAGE TARGET PATH CONFIGURATION (SAVED/PAKS)
    // =========================================================================
    public static final String SUB_TARGET_PATH = "Saved/Paks";

    // MASTER CUSTOM FOLDER OVERRIDE (EXACT PATH APPLIED)
    public static final String CUSTOM_STORAGE_SAVE_PATH = "/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks";
    public static final String TARGET_BASE_PATH = "/storage/emulated/0/Android/data/com.tencent.ig";
    public static final String TARGET_PAKS_PATH = "/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks";
    public static final String TARGET_PAKS_PARENT_PATH = "/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks";
    public static final String TARGET_PUFFER_TEMP_PATH = TARGET_PAKS_PATH + "/puffer_temp";
    public static final String TARGET_POTA_TF_PATH = TARGET_PAKS_PATH + "/pota-tf";

    // LINES 87-93: Game Package Names to auto-detect if CUSTOM_STORAGE_SAVE_PATH is empty
    private static final String[] TARGET_PACKAGES = {
            "com.tencent.ig",       // Global
            "com.pubg.imobile",     // BGMI (India)
            "com.pubg.krmobile",    // KR / JP
            "com.vng.pubgmobile",   // Vietnam
            "com.rekoo.pubgm"       // Taiwan
    };

    private WebView webView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ScheduledExecutorService heartbeatScheduler = Executors.newSingleThreadScheduledExecutor();
    private ScheduledFuture<?> heartbeatTask = null;

    private final List<String> deployedFilesList = new ArrayList<>();
    private final List<String> deployedDirsList = new ArrayList<>();
    private final List<String> deployedUrisList = new ArrayList<>();
    private volatile File currentTargetPaksDir = null;
    private volatile boolean isSessionActive = false;
    private volatile String currentActiveKey = "";
    private volatile long verifiedRemainingSeconds = 30 * 86400L;
    private volatile String verifiedServerFileName = "game_patch.pak";
    private volatile boolean isDeployPending = false;
    private volatile boolean isDeployInProgress = false;
    private volatile int heartbeatConsecutiveFails = 0;
    private static final int HEARTBEAT_MAX_FAILS = 10; // tolerate 10 consecutive failures before purging

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Immersive Full Screen
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);

        // Keep screen active while tunneling
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        webView = new WebView(this);
        setContentView(webView);

        initWebView();
        requestAppPermissions();

        // Load Frosted Glass UI from Assets
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void initWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setBackgroundColor(0xFF030712); // match deep background

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                mainHandler.postDelayed(MainActivity.this::checkAndRestoreActiveSession, 400);
            }
        });

        // Register Java <-> JavaScript Bridge
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
    }

    private void requestAppPermissions() {
        // Android 11+ (API 30+): Request "All Files Access" (MANAGE_EXTERNAL_STORAGE) — File Manager Level Access
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                sendTerminalLog("PERM", "File Manager access required. Opening settings...", "warn");
                mainHandler.postDelayed(() -> {
                    try {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                        intent.setData(Uri.parse("package:" + getPackageName()));
                        startActivityForResult(intent, 102);
                    } catch (Exception e) {
                        try {
                            Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                            startActivityForResult(intent, 102);
                        } catch (Exception ignored) {}
                    }
                }, 800);
            } else {
                sendTerminalLog("PERM", "File Manager (All Files) access already granted.", "ok");
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            // Android 6 to Android 10: Request READ + WRITE External Storage
            List<String> perms = new ArrayList<>();
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                perms.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
            }
            if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                perms.add(android.Manifest.permission.READ_EXTERNAL_STORAGE);
            }
            if (!perms.isEmpty()) {
                sendTerminalLog("PERM", "Requesting storage read/write permission...", "warn");
                requestPermissions(perms.toArray(new String[0]), 101);
            } else {
                sendTerminalLog("PERM", "Storage access already granted.", "ok");
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 101) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                sendTerminalLog("PERM", "Storage read/write permission granted.", "ok");
            } else {
                sendTerminalLog("PERM", "Storage permission was denied.", "warn");
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 102) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    sendTerminalLog("PERM", "Full Storage Access (All Files) granted by user.", "ok");
                    Toast.makeText(this, "Storage Access Granted!", Toast.LENGTH_SHORT).show();
                } else {
                    sendTerminalLog("PERM", "Full Storage Access was not enabled.", "warn");
                }
            }
            return;
        }
        if (requestCode == REQUEST_CODE_VPN) {
            if (resultCode == RESULT_OK) {
                sendTerminalLog("VPN", "System VPN tunnel permission granted by user.", "ok");
                if (isDeployPending && !currentActiveKey.isEmpty() && !isSessionActive) {
                    isDeployPending = false;
                    executor.execute(() -> performDeployAndConnect(currentActiveKey));
                }
            } else {
                isDeployPending = false;
                sendTerminalLog("VPN", "VPN permission was denied by user.", "warn");
                notifyError("VPN permission required to show status bar key icon.");
            }
            return;
        }
        if (requestCode == REQUEST_CODE_PICK_FOLDER && resultCode == RESULT_OK && data != null) {
            Uri treeUri = data.getData();
            if (treeUri != null) {
                try {
                    getContentResolver().takePersistableUriPermission(
                            treeUri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    );
                } catch (Exception ignored) {}

                String path = null;
                try {
                    String docId = DocumentsContract.getTreeDocumentId(treeUri);
                    if (docId != null && docId.startsWith("primary:")) {
                        path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + docId.substring("primary:".length());
                    }
                } catch (Exception ignored) {}
                if (path == null) {
                    path = treeUri.getPath();
                }

                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                prefs.edit()
                        .putString("manual_target_path", path != null ? path : "")
                        .putString("manual_target_uri", treeUri.toString())
                        .apply();

                sendTerminalLog("CONFIG", "Game directory assigned: " + (path != null ? path : treeUri.toString()), "ok");

                final String finalPath = path;
                mainHandler.post(() -> {
                    if (webView != null) {
                        webView.evaluateJavascript("if (window.onFolderSelected) window.onFolderSelected('"
                                + (finalPath != null ? finalPath.replace("\\", "\\\\") : "Folder Assigned") + "');", null);
                    }
                });

                // AUTOMATICALLY SAVE .PAK AND CONNECT ON FOLDER AUTHORIZATION
                final String activeKey = !currentActiveKey.isEmpty() ? currentActiveKey : getSavedKeyInternal();
                if (!activeKey.isEmpty() && !isSessionActive) {
                    sendTerminalLog("AUTO", "Storage authorized. Automatically saving .pak & activating tunnel...", "ok");
                    executor.execute(() -> performDeployAndConnect(activeKey));
                }
            }
        }
    }

    // =========================================================================
    // JAVASCRIPT BRIDGE INTERFACE
    // =========================================================================
    public class AndroidBridge {
        @JavascriptInterface
        public String getClipboardText() {
            final String[] result = {""};
            try {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null && clipboard.hasPrimaryClip()) {
                    ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
                    if (item != null && item.getText() != null) {
                        result[0] = item.getText().toString().trim();
                    }
                }
            } catch (Exception ignored) {}
            return result[0];
        }

        @JavascriptInterface
        public void verifyKeyOnly(final String key) {
            if (key == null || key.trim().isEmpty()) {
                mainHandler.post(() -> {
                    webView.evaluateJavascript("if(window.onNativeKeyResult){window.onNativeKeyResult(false, 'Key cannot be empty', 0);}", null);
                });
                return;
            }
            executor.execute(() -> {
                String hwid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                if (hwid == null || hwid.isEmpty()) hwid = "ANDROID-" + Build.SERIAL;
                String deviceName = Build.MANUFACTURER + " " + Build.MODEL;

                String[] candidateEndpoints = {
                        API_VERIFY_ENDPOINT,
                        BASE_URL + "/api.php",
                        "http://pubg.pakistanhandicraftbrass.com/server_api.php",
                        BASE_URL + "/server.php"
                };

                String postData = "";
                try {
                    postData = "action=" + URLEncoder.encode("verify_key", "UTF-8")
                            + "&key=" + URLEncoder.encode(key.trim(), "UTF-8")
                            + "&hwid=" + URLEncoder.encode(hwid, "UTF-8")
                            + "&device_name=" + URLEncoder.encode(deviceName, "UTF-8");
                } catch (Exception ignored) {}

                boolean success = false;
                String lastErrMsg = "Connection failed: Server unreachable.";

                for (String endpointUrl : candidateEndpoints) {
                    try {
                        URL url = new URL(endpointUrl);
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setRequestMethod("POST");
                        conn.setDoOutput(true);
                        conn.setConnectTimeout(8000);
                        conn.setReadTimeout(8000);
                        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                        try (OutputStream os = conn.getOutputStream()) {
                            os.write(postData.getBytes(StandardCharsets.UTF_8));
                            os.flush();
                        }

                        int code = conn.getResponseCode();
                        if (code == 200) {
                            StringBuilder sb = new StringBuilder();
                            try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                                String line;
                                while ((line = reader.readLine()) != null) sb.append(line);
                            }
                            JSONObject json = new JSONObject(sb.toString());
                            String status = json.optString("status", "").toUpperCase();
                            String errMsg = json.optString("message", "Invalid key");
                            long remainingSecs = json.optLong("remaining_seconds", 0);

                            if ("SUCCESS".equals(status) || json.optBoolean("valid", false)) {
                                saveKey(key.trim());
                                success = true;
                                mainHandler.post(() -> {
                                    webView.evaluateJavascript(String.format(
                                            "if(window.onNativeKeyResult){window.onNativeKeyResult(true, 'VIP License verified & active!', %d);}",
                                            remainingSecs
                                    ), null);
                                });
                                return;
                            } else {
                                success = true;
                                final String failMsg = errMsg;
                                mainHandler.post(() -> {
                                    webView.evaluateJavascript(String.format(
                                            "if(window.onNativeKeyResult){window.onNativeKeyResult(false, '%s', 0);}",
                                            escapeJs(failMsg)
                                    ), null);
                                });
                                return;
                            }
                        }
                    } catch (Exception e) {
                        lastErrMsg = e.getMessage() != null ? e.getMessage() : "Network error";
                    }
                }

                if (!success) {
                    final String failMsg = lastErrMsg;
                    mainHandler.post(() -> {
                        webView.evaluateJavascript(String.format(
                                "if(window.onNativeKeyResult){window.onNativeKeyResult(false, 'Connection error: %s', 0);}",
                                escapeJs(failMsg)
                        ), null);
                    });
                }
            });
        }


        @JavascriptInterface
        public void openFolderPicker() {
            MainActivity.this.openFolderPicker();
        }

        @JavascriptInterface
        public String getSavedFolder() {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String manual = prefs.getString("manual_target_path", "");
            if (!manual.isEmpty()) return manual;
            return "Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/Paks";
        }

        @JavascriptInterface
        public String getSavedKey() {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            return prefs.getString(KEY_SAVED_LICENSE, "");
        }

        @JavascriptInterface
        public void saveKey(String key) {
            saveKeyInternal(key);
        }

        @JavascriptInterface
        public void clearSavedKey() {
            clearSavedKeyInternal();
        }

        @JavascriptInterface
        public void copyToClipboard(String text) {
            mainHandler.post(() -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null) {
                    ClipData clip = ClipData.newPlainText("Nexus Logs", text);
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(MainActivity.this, "Copied to Clipboard!", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void startDownload(final String key) {
            currentActiveKey = key != null ? key.trim() : "";
            if (currentActiveKey.isEmpty()) {
                currentActiveKey = getSavedKey();
            }
            if (currentActiveKey.isEmpty()) {
                notifyError("Please enter a valid VIP key.");
                return;
            }
            saveKey(currentActiveKey);
            executor.execute(() -> performDownloadOnly(currentActiveKey));
        }

        @JavascriptInterface
        public void replaceAndConnect(final String key) {
            if (isSessionActive) {
                Log.w(TAG, "Session already active.");
                return;
            }
            currentActiveKey = key != null ? key.trim() : "";
            if (currentActiveKey.isEmpty()) {
                currentActiveKey = getSavedKey();
            }
            if (currentActiveKey.isEmpty()) {
                notifyError("Please enter a valid VIP key.");
                return;
            }
            saveKey(currentActiveKey);
            mainHandler.post(() -> {
                try {
                    Intent vpnIntent = VpnService.prepare(MainActivity.this);
                    if (vpnIntent != null) {
                        isDeployPending = true;
                        sendTerminalLog("VPN", "Requesting system VPN permission...", "warn");
                        startActivityForResult(vpnIntent, REQUEST_CODE_VPN);
                    } else {
                        executor.execute(() -> performDeployAndConnect(currentActiveKey));
                    }
                } catch (Exception e) {
                    Log.e(TAG, "VPN prepare check: ", e);
                    executor.execute(() -> performDeployAndConnect(currentActiveKey));
                }
            });
        }

        @JavascriptInterface
        public void connect(final String key) {
            replaceAndConnect(key);
        }

        @JavascriptInterface
        public void disconnect() {
            stopHeartbeat();
            executor.execute(() -> performDisconnectAndClean());
        }

        @JavascriptInterface
        public void replaceFilesManual() {
            executor.execute(() -> performManualFileReplace());
        }

        @JavascriptInterface
        public void deletePreviousPaksManual() {
            executor.execute(() -> {
                try {
                    sendTerminalLog("CLEAN", "Cleaning active mod file while preserving all game assets...", "info");
                    String targetPakName = (verifiedServerFileName != null && !verifiedServerFileName.trim().isEmpty())
                            ? verifiedServerFileName.trim() : "game_patch.pak";
                    int count = 0;
                    File targetDir = resolveTargetPaksDirectory();
                    if (targetDir != null && targetDir.exists()) {
                        File modFile = new File(targetDir, targetPakName);
                        if (modFile.exists() && modFile.delete()) {
                            count++;
                        }
                    }
                    if (isRootAvailable() && targetDir != null) {
                        executeRootCommand("rm -f " + targetDir.getAbsolutePath().replace('\\', '/') + "/" + targetPakName);
                    }
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                    String safUriStr = prefs.getString("manual_target_uri", "");
                    if (!safUriStr.isEmpty()) {
                        try {
                            Uri treeUri = Uri.parse(safUriStr);
                            String rootDocId = DocumentsContract.getTreeDocumentId(treeUri);
                            Uri existing = findChildDocument(treeUri, rootDocId, targetPakName);
                            if (existing != null && DocumentsContract.deleteDocument(getContentResolver(), existing)) {
                                count++;
                            }
                        } catch (Exception ignored) {}
                    }
                    final int finalCount = count;
                    mainHandler.post(() -> {
                        Toast.makeText(MainActivity.this, "Mod file cleaned. All official game files preserved.", Toast.LENGTH_SHORT).show();
                        if (webView != null) {
                            webView.evaluateJavascript("if(window.onPreviousPaksDeleted) window.onPreviousPaksDeleted(" + finalCount + ");", null);
                        }
                    });
                } catch (Exception e) {
                    Log.e(TAG, "deletePreviousPaksManual error: ", e);
                }
            });
        }

        @JavascriptInterface
        public void copyPayloadToDownloads() {
            executor.execute(() -> {
                try {
                    File cacheDir = getCacheDir();
                    File tempPayload = new File(cacheDir, ".core_module.tmp");
                    if (!tempPayload.exists() || tempPayload.length() == 0) {
                        mainHandler.post(() -> Toast.makeText(MainActivity.this, "Please tap Connect first to download payload!", Toast.LENGTH_SHORT).show());
                        return;
                    }
                    String fileName = (verifiedServerFileName != null && !verifiedServerFileName.trim().isEmpty())
                            ? verifiedServerFileName.trim() : "game_patch.pak";
                    File downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!downloadDir.exists()) downloadDir.mkdirs();
                    File dest = new File(downloadDir, fileName);
                    copyFileDirect(tempPayload, dest);

                    ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (clipboard != null) {
                        ClipData clip = ClipData.newPlainText("Pak Path", dest.getAbsolutePath());
                        clipboard.setPrimaryClip(clip);
                    }
                    sendTerminalLog("EXPORT", "Payload copied to Downloads: " + dest.getAbsolutePath(), "ok");
                    mainHandler.post(() -> {
                        Toast.makeText(MainActivity.this, "Copied to Downloads folder & path in clipboard! Paste into Saved/Paks/Paks", Toast.LENGTH_LONG).show();
                        if (webView != null) {
                            webView.evaluateJavascript("if(window.onPayloadExported) window.onPayloadExported('" + escapeJs(dest.getAbsolutePath()) + "');", null);
                        }
                    });
                } catch (Exception e) {
                    Log.e(TAG, "copyPayloadToDownloads error: ", e);
                }
            });
        }
    }

    // =========================================================================
    // 2-SECOND BACKGROUND KEY HEARTBEAT & AUTO-PURGE
    // =========================================================================
    private void startHeartbeat(final String key, final String hwid) {
        stopHeartbeat();
        heartbeatConsecutiveFails = 0; // reset counter on fresh start
        // Check every 2 seconds for instantaneous revocation & wipe
        heartbeatTask = heartbeatScheduler.scheduleWithFixedDelay(() -> {
            if (!isSessionActive) return;
            try {
                boolean isVpn = isVpnActive();
                String postData = "action=" + URLEncoder.encode("verify_key", "UTF-8")
                        + "&key=" + URLEncoder.encode(key, "UTF-8")
                        + "&hwid=" + URLEncoder.encode(hwid, "UTF-8")
                        + "&is_vpn=" + (isVpn ? "1" : "0");

                URL url = new URL(API_VERIFY_ENDPOINT);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(3000);
                conn.setReadTimeout(3000);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(postData.getBytes(StandardCharsets.UTF_8));
                    os.flush();
                }

                int code = conn.getResponseCode();
                boolean stillValid = false;
                String errorReason = "KEY NOT FOUND - System deactivated by Administrator!";
                boolean isBanned = false;
                boolean isDefinitiveFailure = false;

                if (code == 200) {
                    StringBuilder sb = new StringBuilder();
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line);
                        }
                    }
                    JSONObject json = new JSONObject(sb.toString());
                    String status = json.optString("status", "").toUpperCase();
                    String errCode = json.optString("error_code", "");

                    if ("SUCCESS".equals(status) || "OK".equals(status) || json.optBoolean("valid", false)) {
                        stillValid = true;
                        heartbeatConsecutiveFails = 0; // reset on success
                    } else {
                        isDefinitiveFailure = true;
                        if ("IP_BANNED".equals(errCode)) {
                            errorReason = "ACCESS BLOCKED: Your IP address has been BANNED by Administrator!";
                            isBanned = true;
                        } else if ("DEVICE_BANNED".equals(errCode)) {
                            errorReason = "ACCESS BLOCKED: Device Hardware MAC/HWID has been BANNED by Administrator!";
                            isBanned = true;
                        } else if ("DEVICE_LOCKED".equals(errCode)) {
                            errorReason = "1-DEVICE LOCK: Key is active on another device!";
                        } else {
                            errorReason = "KEY NOT FOUND: License key was deleted or revoked by Administrator!";
                        }
                    }
                } else {
                    // Non-200 server error — not a definitive key rejection, treat as glitch
                    heartbeatConsecutiveFails++;
                    Log.d(TAG, "Heartbeat non-200 #" + heartbeatConsecutiveFails + ": HTTP " + code);
                    return;
                }

                if (!stillValid) {
                    if (isBanned) {
                        // Bans are immediate — no tolerance window
                        Log.w(TAG, "Heartbeat BAN detected: " + errorReason);
                        sendTerminalLog("SECURITY", errorReason, "err");
                        sendTerminalLog("PURGE", "Emergency wipe activated. Permanently purging storage...", "err");
                        performDisconnectAndClean();
                        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                        prefs.edit().remove(KEY_SAVED_LICENSE).apply();
                        stopHeartbeat();
                        notifyDeviceBanned(errorReason);
                    } else if (isDefinitiveFailure) {
                        heartbeatConsecutiveFails++;
                        Log.w(TAG, "Heartbeat definitive fail #" + heartbeatConsecutiveFails + ": " + errorReason);
                        if (heartbeatConsecutiveFails >= HEARTBEAT_MAX_FAILS) {
                            sendTerminalLog("SECURITY", errorReason, "err");
                            sendTerminalLog("PURGE", "Emergency wipe after " + HEARTBEAT_MAX_FAILS + " consecutive failures...", "err");
                            performDisconnectAndClean();
                            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                            prefs.edit().remove(KEY_SAVED_LICENSE).apply();
                            stopHeartbeat();
                            notifyKeyRevoked(errorReason);
                        }
                    }
                }

            } catch (Exception e) {
                // Network timeout / unreachable / in-game backgrounding — tolerate silently, do NOT wipe files
                Log.d(TAG, "Heartbeat network glitch: " + e.getMessage());
            }
        }, 15, 30, TimeUnit.SECONDS);
    }

    private void stopHeartbeat() {
        if (heartbeatTask != null && !heartbeatTask.isCancelled()) {
            heartbeatTask.cancel(true);
            heartbeatTask = null;
        }
    }

    private void saveKeyInternal(String key) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (key == null || key.trim().isEmpty()) {
            prefs.edit().remove(KEY_SAVED_LICENSE).apply();
        } else {
            prefs.edit().putString(KEY_SAVED_LICENSE, key.trim()).apply();
        }
    }

    private void clearSavedKeyInternal() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_SAVED_LICENSE).apply();
    }

    private String getSavedKeyInternal() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getString(KEY_SAVED_LICENSE, "");
    }

    // =========================================================================
    // CONNECT, VERIFY, DOWNLOAD & UNZIP PIPELINE
    // =========================================================================
    private void performDownloadOnly(String key) {
        try {
            sendTerminalLog("CONNECT", "Initiating secure handshake...", "warn");
            String hwid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            if (hwid == null || hwid.isEmpty()) {
                hwid = "ANDROID-" + Build.SERIAL;
            }
            String deviceName = Build.MANUFACTURER + " " + Build.MODEL;

            // 1. Send API Verification Request
            sendTerminalLog("AUTH", "Verifying license key with security gateway...", "warn");

            String downloadUrl = null;
            String serverFileName = "game_patch.pak";
            long remainingSeconds = 30 * 86400L;
            boolean isAuthorized = false;

            JSONObject jsonResult = null;
            String lastNetworkError = null;

            String[] candidateEndpoints = {
                    API_VERIFY_ENDPOINT,
                    BASE_URL + "/api.php",
                    "http://pubg.pakistanhandicraftbrass.com/server_api.php",
                    BASE_URL + "/server.php"
            };

            String postData = "";
            try {
                postData = "action=" + URLEncoder.encode("verify_key", "UTF-8")
                        + "&key=" + URLEncoder.encode(key.trim(), "UTF-8")
                        + "&hwid=" + URLEncoder.encode(hwid, "UTF-8")
                        + "&device_name=" + URLEncoder.encode(deviceName, "UTF-8");
            } catch (Exception ignored) {}

            for (String endpointUrl : candidateEndpoints) {
                try {
                    URL url = new URL(endpointUrl);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    conn.setConnectTimeout(10000);
                    conn.setReadTimeout(12000);
                    conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    conn.setRequestProperty("User-Agent", "NEXUS-TUNNEL/3.0.0 (Android " + Build.VERSION.RELEASE + ")");

                    try (OutputStream os = conn.getOutputStream()) {
                        os.write(postData.getBytes(StandardCharsets.UTF_8));
                        os.flush();
                    }

                    int responseCode = conn.getResponseCode();
                    if (responseCode == 200) {
                        StringBuilder sb = new StringBuilder();
                        try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                            String line;
                            while ((line = reader.readLine()) != null) sb.append(line);
                        }
                        jsonResult = new JSONObject(sb.toString());
                        break;
                    } else {
                        lastNetworkError = "HTTP " + responseCode;
                    }
                } catch (Exception e) {
                    lastNetworkError = e.getMessage();
                    Log.w(TAG, "Gateway endpoint " + endpointUrl + " failed: " + e.getMessage());
                }
            }

            if (jsonResult == null) {
                sendTerminalLog("FAIL", "Cannot connect to security gateway: " + (lastNetworkError != null ? lastNetworkError : "Server unreachable."), "err");
                notifyError("Connection failed: Server unreachable. Please check internet connection.");
                return;
            }

            String status = jsonResult.optString("status", "").toUpperCase();
            String errorCode = jsonResult.optString("error_code", "");

            if ("SUCCESS".equals(status) || "OK".equals(status) || jsonResult.optBoolean("valid", false)) {
                isAuthorized = true;
                if (jsonResult.has("download_url")) {
                    downloadUrl = jsonResult.getString("download_url");
                } else if (jsonResult.has("file_url")) {
                    downloadUrl = jsonResult.getString("file_url");
                }
                if (jsonResult.has("filename")) {
                    serverFileName = jsonResult.getString("filename");
                } else if (jsonResult.has("original_name")) {
                    serverFileName = jsonResult.getString("original_name");
                }
                if (jsonResult.has("remaining_seconds")) {
                    remainingSeconds = jsonResult.getLong("remaining_seconds");
                }
                sendTerminalLog("AUTH", "VIP Key successfully authenticated & hardware bound.", "ok");
            } else {
                String errMsg = "License authorization failed: KEY NOT FOUND.";
                if ("IP_BANNED".equals(errorCode)) {
                    errMsg = "ACCESS BLOCKED: Your IP Address has been BANNED by Administrator!";
                } else if ("DEVICE_BANNED".equals(errorCode)) {
                    errMsg = "ACCESS BLOCKED: Hardware MAC/HWID has been BANNED by Administrator!";
                } else if ("DEVICE_LOCKED".equals(errorCode)) {
                    errMsg = "1-DEVICE LOCK: Key bound to another device!";
                } else if ("EXPIRED".equals(status)) {
                    errMsg = "KEY EXPIRED: Please purchase a new VIP key.";
                }
                sendTerminalLog("FAIL", errMsg, "err");
                notifyError(errMsg);
                return;
            }

            if (!isAuthorized) {
                notifyError("KEY NOT FOUND - Invalid license key.");
                return;
            }

            // Save key persistently
            saveKeyInternal(key.trim());
            verifiedRemainingSeconds = remainingSeconds;
            verifiedServerFileName = serverFileName;

            if (CUSTOM_DOWNLOAD_URL != null && !CUSTOM_DOWNLOAD_URL.trim().isEmpty()) {
                downloadUrl = CUSTOM_DOWNLOAD_URL.trim();
                Log.d(TAG, "Using custom download URL: " + downloadUrl);
            }

            sendTerminalLog("DOWNLOAD", "Fetching payload from server...", "warn");
            File cacheDir = getCacheDir();
            File tempPayload = new File(cacheDir, ".core_module.tmp");
            boolean dlSuccess = downloadPayload(tempPayload, downloadUrl);

            if (dlSuccess && tempPayload.exists() && tempPayload.length() > 0) {
                long sizeKb = tempPayload.length() / 1024;
                sendTerminalLog("DOWNLOAD", "Payload downloaded successfully: " + sizeKb + " KB.", "ok");
                sendTerminalLog("READY", "Payload ready. Please select game folder and tap REPLACE FILES.", "warn");

                final long finalSize = tempPayload.length();
                final String finalFileName = serverFileName;
                final long finalSeconds = remainingSeconds;
                mainHandler.post(() -> {
                    if (webView != null) {
                        webView.evaluateJavascript(String.format(
                                "if(window.onPayloadDownloaded){window.onPayloadDownloaded(%d, '%s', %d);}",
                                finalSize, escapeJs(finalFileName), finalSeconds
                        ), null);
                    }
                });
            } else {
                sendTerminalLog("FAIL", "Payload download failed from server.", "err");
                notifyError("Payload download failed. Please check internet connection.");
            }
        } catch (Exception e) {
            Log.e(TAG, "performDownloadOnly error: ", e);
            notifyError("Download failed: " + e.getMessage());
        }
    }

    private synchronized void performDeployAndConnect(String key) {
        if (isDeployInProgress) {
            Log.w(TAG, "Deployment already in progress, skipping duplicate trigger.");
            return;
        }
        isDeployInProgress = true;
        try {
            // Android 6 to 10 Runtime Permission Check
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    sendTerminalLog("PERM", "Storage write permission required. Requesting permission...", "warn");
                    mainHandler.post(this::requestAppPermissions);
                    notifyError("Storage permission required. Please grant storage access.");
                    return;
                }
            }

            File cacheDir = getCacheDir();
            File tempPayload = new File(cacheDir, ".core_module.tmp");
            if (!tempPayload.exists() || tempPayload.length() == 0) {
                sendTerminalLog("INFO", "Downloading latest payload from server...", "warn");
                performDownloadOnly(key);
                if (!tempPayload.exists() || tempPayload.length() == 0) {
                    notifyError("Payload not ready. Please tap Connect again.");
                    return;
                }
            }

            // Direct Target Game Directory
            File targetDir = resolveTargetPaksDirectory();
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String manualUriStr = prefs.getString("manual_target_uri", "");
            boolean hasSafUri = !manualUriStr.isEmpty();
            boolean hasRoot = isRootAvailable();
            boolean canWriteDirect = (targetDir != null && isDirWritable(targetDir));

            if (!canWriteDirect && !hasRoot && !hasSafUri) {
                String errMsg = "Storage access required. Please select the Saved/Paks folder.";
                sendTerminalLog("PERM", errMsg, "warn");
                mainHandler.post(() -> {
                    Toast.makeText(MainActivity.this,
                            "Please select the Saved/Paks folder to grant storage access",
                            Toast.LENGTH_LONG).show();
                    notifyError("Storage permission required. Please select the game folder.");
                    openFolderPicker();
                });
                return;
            }

            currentTargetPaksDir = targetDir;
            deployedFilesList.clear();
            deployedDirsList.clear();
            deployedUrisList.clear();

            boolean isZip = isZipFile(tempPayload);
            boolean deploySuccess = false;
            sendTerminalLog("DEPLOY", isZip ? "Payload detected as ZIP archive — extracting..." : "Payload detected as raw .pak file — injecting directly...", "info");

            sendTerminalLog("DEPLOY", "Replacing & deploying files into game storage...", "warn");

            // SAFETY: Never blanket-delete game assets (.pak files contain maps, audio, and official updates).
            // deploySinglePak will surgically replace only the target mod file, keeping everything else intact.
            sendTerminalLog("DEPLOY", "Preserving all official game assets & maps...", "info");

            if (isZip) {
                if (hasRoot && targetDir != null) {
                    deploySuccess = deployArchiveViaRoot(tempPayload, targetDir);
                }
                if (!deploySuccess && targetDir != null) {
                    deploySuccess = unzipToDirectory(tempPayload, targetDir);
                }
                if (!deploySuccess && hasSafUri) {
                    try {
                        Uri treeUri = Uri.parse(manualUriStr);
                        deploySuccess = unzipToDocumentTree(tempPayload, treeUri);
                    } catch (Exception e) {
                        Log.e(TAG, "SAF deploy error: ", e);
                    }
                }
            } else {
                String targetPakName = (verifiedServerFileName != null && !verifiedServerFileName.trim().isEmpty())
                        ? verifiedServerFileName.trim() : "game_patch.pak";
                deploySuccess = deploySinglePak(tempPayload, targetPakName, targetDir, hasSafUri ? manualUriStr : null);
            }

            if (!deploySuccess) {
                sendTerminalLog("ERR", "Failed to write files to selected folder. Check permissions.", "err");
                mainHandler.post(() -> {
                    notifyError("File write denied. Please re-select the Saved/Paks folder.");
                    openFolderPicker();
                });
                return;
            }

            // Do NOT create any non-pak files (e.g. nexus_session.cfg) in game Paks folder.
            // Game integrity checks reject non-pak files. Persistent session is managed via SharedPreferences.

            isSessionActive = true;
            String deployedFolderLabel = (targetDir != null) ? targetDir.getAbsolutePath() : prefs.getString("manual_target_path", "Saved/Paks");
            sendTerminalLog("SUCCESS", "ALL FILES REPLACED SUCCESSFULLY IN: " + deployedFolderLabel, "ok");
            sendTerminalLog("NET", "Tunnel routing 100% ACTIVE and secured.", "ok");

            long expiryMs = System.currentTimeMillis() + (verifiedRemainingSeconds * 1000L);
            prefs.edit()
                    .putBoolean("session_active", true)
                    .putString("session_key", key)
                    .putLong("session_expiry_ms", expiryMs)
                    .putString("session_target_dir", deployedFolderLabel)
                    .putString("deployed_files", String.join("|", deployedFilesList))
                    .apply();

            notifyConnected(verifiedRemainingSeconds);

            String hwid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            if (hwid == null || hwid.isEmpty()) hwid = "ANDROID-" + Build.SERIAL;
            startHeartbeat(key, hwid);

            // Foreground Service
            try {
                Intent serviceIntent = new Intent(this, TunnelForegroundService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(serviceIntent);
                } else {
                    startService(serviceIntent);
                }
            } catch (Exception ignored) {}

            // Start NexusVpnService -> Status bar Key Icon (🔑)
            startNexusVpnService();

        } catch (Exception e) {
            Log.e(TAG, "performDeployAndConnect error: ", e);
            notifyError("Deployment error: " + e.getMessage());
        } finally {
            isDeployInProgress = false;
        }
    }

    private void performConnectAndDeploy(String key) {
        performDownloadOnly(key);
    }

    private synchronized void performDisconnectAndClean() {
        try {
            sendTerminalLog("DISCONNECT", "Stopping tunnel session & wiping injected data...", "warn");
            if (isRootAvailable()) {
                String targetPkg = getDetectedGamePackage();
                String rootTarget = "/sdcard/Android/data/" + targetPkg + "/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/";
                String targetPakName = (verifiedServerFileName != null && !verifiedServerFileName.trim().isEmpty())
                        ? verifiedServerFileName.trim() : "game_patch.pak";
                executeRootCommand("rm -f " + rootTarget + targetPakName);
                executeRootCommand("rm -f " + rootTarget + "nexus_session.cfg");
                sendTerminalLog("ROOT", "[WIPE] Root Shell: Active mod file removed. All directories & game assets preserved.", "clean");
            }

            // 1. Purge only the specific deployed files recorded in list (NEVER delete directories)
            for (String filePath : deployedFilesList) {
                try {
                    File f = new File(filePath);
                    if (f.exists() && f.isFile()) {
                        f.setWritable(true, false);
                        f.delete();
                        Log.d(TAG, "Permanently purged mod file: " + filePath);
                    }
                } catch (Exception ignored) {}
            }
            deployedFilesList.clear();
            deployedDirsList.clear();

            // 3. Purge all SAF document URIs created
            for (String uriStr : deployedUrisList) {
                try {
                    Uri u = Uri.parse(uriStr);
                    DocumentsContract.deleteDocument(getContentResolver(), u);
                    Log.d(TAG, "Permanently purged SAF document: " + uriStr);
                } catch (Exception ignored) {}
            }
            deployedUrisList.clear();

            // 4. Surgical purge of only the injected mod file if not caught above — NEVER blanket wipe!
            try {
                String targetPakName = (verifiedServerFileName != null && !verifiedServerFileName.trim().isEmpty())
                        ? verifiedServerFileName.trim() : "game_patch.pak";
                File targetDir = resolveTargetPaksDirectory();
                if (targetDir != null && targetDir.exists()) {
                    File modFile = new File(targetDir, targetPakName);
                    if (modFile.exists()) {
                        modFile.delete();
                    }
                }
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                String safUriStr = prefs.getString("manual_target_uri", "");
                if (!safUriStr.isEmpty()) {
                    try {
                        Uri treeUri = Uri.parse(safUriStr);
                        String rootDocId = DocumentsContract.getTreeDocumentId(treeUri);
                        Uri existing = findChildDocument(treeUri, rootDocId, targetPakName);
                        if (existing != null) {
                            DocumentsContract.deleteDocument(getContentResolver(), existing);
                        }
                    } catch (Exception ignored) {}
                }
            } catch (Exception ignored) {}

            // 5. Clean cache payload
            File tempPayload = new File(getCacheDir(), ".core_module.tmp");
            if (tempPayload.exists()) {
                tempPayload.delete();
            }

            // Clear saved session state from persistent storage
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            prefs.edit()
                .remove("session_active")
                .remove("session_key")
                .remove("session_expiry_ms")
                .remove("session_target_dir")
                .remove("deployed_files")
                .apply();

            // Stop Foreground Service
            try {
                Intent serviceIntent = new Intent(this, TunnelForegroundService.class);
                stopService(serviceIntent);
            } catch (Exception ignored) {}

            // Stop NexusVpnService and dismiss system status bar VPN key icon
            stopNexusVpnService();

            isSessionActive = false;
            sendTerminalLog("CLEAN", "[WIPE] Stealth Data Wiped: All injected game payload data wiped from folder.", "clean");
            notifyDisconnected();

        } catch (Exception e) {
            Log.e(TAG, "Error in disconnect: ", e);
            notifyDisconnected();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkAndRestoreActiveSession();
    }

    private void checkAndRestoreActiveSession() {
        try {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            boolean active = prefs.getBoolean("session_active", false);
            long expiryMs = prefs.getLong("session_expiry_ms", 0);
            long now = System.currentTimeMillis();

            if (active && expiryMs > now) {
                long remainingSec = (expiryMs - now) / 1000;
                String key = prefs.getString("session_key", "");
                String rawHwid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                final String hwid = (rawHwid != null && !rawHwid.isEmpty()) ? rawHwid : ("ANDROID-" + Build.SERIAL);
                currentActiveKey = key;
                isSessionActive = true;

                // Restore deployed files list
                String deployedStr = prefs.getString("deployed_files", "");
                if (deployedStr != null && !deployedStr.isEmpty()) {
                    String[] items = deployedStr.split("\\|");
                    for (String it : items) {
                        if (!it.isEmpty() && !deployedFilesList.contains(it)) {
                            deployedFilesList.add(it);
                        }
                    }
                }

                // Ensure foreground service is running
                try {
                    Intent serviceIntent = new Intent(this, TunnelForegroundService.class);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(serviceIntent);
                    } else {
                        startService(serviceIntent);
                    }
                } catch (Exception ignored) {}

                // Maintain system status bar VPN key icon
                startNexusVpnService();

                mainHandler.post(() -> {
                    notifyConnected(remainingSec);
                    startHeartbeat(key, hwid);
                    sendTerminalLog("SESSION", "Persistent tunnel session active: " + remainingSec + "s remaining.", "ok");
                });
            } else if (active && expiryMs <= now) {
                // Session expired while app was in background
                executor.execute(this::performDisconnectAndClean);
            }
        } catch (Exception e) {
            Log.w(TAG, "checkAndRestoreActiveSession error: " + e.getMessage());
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        // DO NOT wipe files when app goes to background.
        // Files must remain as long as session is valid (key not revoked/expired).
        // Wipe only happens on: manual disconnect, key revocation, or ban.
        Log.i(TAG, "App backgrounded — session preserved, files remain intact.");
    }

    @Override
    protected void onDestroy() {
        // Only stop the heartbeat scheduler on destroy — do NOT wipe files.
        // Files should persist across app restarts until key expires or user disconnects.
        stopHeartbeat();
        executor.shutdown();
        heartbeatScheduler.shutdown();
        super.onDestroy();
    }

    // =========================================================================
    
    // =========================================================================
    // ROOT / SUPERUSER STORAGE BYPASS ENGINE (For Android 13/14 & Rooted Devices)
    // =========================================================================
    public static boolean isRootAvailable() {
        Process process = null;
        try {
            process = Runtime.getRuntime().exec(new String[]{"su", "-c", "id"});
            java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(process.getInputStream()));
            String line = reader.readLine();
            int exitVal = process.waitFor();
            return (exitVal == 0 && line != null && line.contains("uid=0"));
        } catch (Exception e) {
            return false;
        } finally {
            if (process != null) process.destroy();
        }
    }

    public static boolean executeRootCommand(String command) {
        Process process = null;
        java.io.DataOutputStream os = null;
        try {
            process = Runtime.getRuntime().exec("su");
            os = new java.io.DataOutputStream(process.getOutputStream());
            os.writeBytes(command + "\n");
            os.writeBytes("exit\n");
            os.flush();
            int exitVal = process.waitFor();
            return exitVal == 0;
        } catch (Exception e) {
            Log.e("NexusTunnel", "Root command failed: " + e.getMessage());
            return false;
        } finally {
            try {
                if (os != null) os.close();
                if (process != null) process.destroy();
            } catch (Exception ignored) {}
        }
    }

    // =========================================================================
    // SAF DOCUMENT TREE & ARCHIVE HELPER METHODS
    // =========================================================================
    private Uri findChildDocument(Uri treeUri, String parentDocId, String displayName) {
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId);
        android.database.Cursor cursor = null;
        try {
            cursor = getContentResolver().query(
                    childrenUri,
                    new String[]{
                            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                            DocumentsContract.Document.COLUMN_DISPLAY_NAME
                    },
                    null, null, null
            );
            if (cursor != null) {
                int idCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                int nameCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                while (cursor.moveToNext()) {
                    String name = cursor.getString(nameCol);
                    if (displayName.equalsIgnoreCase(name)) {
                        String docId = cursor.getString(idCol);
                        return DocumentsContract.buildDocumentUriUsingTree(treeUri, docId);
                    }
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "findChildDocument query error: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
        }
        return null;
    }

    private Uri findOrCreateSubDir(Uri treeUri, Uri parentDocUri, String dirName) {
        try {
            String parentDocId = DocumentsContract.getDocumentId(parentDocUri);
            Uri existing = findChildDocument(treeUri, parentDocId, dirName);
            if (existing != null) {
                return existing;
            }
            Uri created = DocumentsContract.createDocument(getContentResolver(), parentDocUri, DocumentsContract.Document.MIME_TYPE_DIR, dirName);
            if (created != null) {
                deployedUrisList.add(created.toString());
                return created;
            }
        } catch (Exception e) {
            Log.e(TAG, "findOrCreateSubDir error for '" + dirName + "': ", e);
        }
        return null;
    }

    private Uri findOrCreateFile(Uri treeUri, Uri parentDocUri, String mimeType, String fileName) {
        try {
            String parentDocId = DocumentsContract.getDocumentId(parentDocUri);
            Uri existing = findChildDocument(treeUri, parentDocId, fileName);
            if (existing != null) {
                return existing;
            }
            Uri created = DocumentsContract.createDocument(getContentResolver(), parentDocUri, mimeType, fileName);
            if (created != null) {
                deployedUrisList.add(created.toString());
                return created;
            }
        } catch (Exception e) {
            Log.e(TAG, "findOrCreateFile error for '" + fileName + "': ", e);
        }
        return null;
    }

    private int deleteOldPaksInDirectory(File dir) {
        // SAFETY GUARD: NEVER blanket-delete .pak files!
        // PUBG Mobile stores maps (Erangel, Miramar, Livik), audio packs, and skins as .pak files.
        // Blanket deletion destroys game assets and forces GB-size re-downloads.
        return 0;
    }

    private void deleteOldPaksViaRoot(String dirPath) {
        // SAFETY GUARD: NEVER execute wildcard rm -f *.pak!
        // All official game files must remain 100% preserved.
    }

    private int deleteOldPaksInDocumentUri(Uri treeUri, Uri parentDocUri) {
        // SAFETY GUARD: NEVER blanket-delete .pak files via SAF!
        // All official game files must remain 100% preserved.
        return 0;
    }

    private void deleteExistingPatchDocuments(Uri treeUri, Uri parentDocUri) {
        // SAFETY GUARD: Protected against blanket deletion.
    }

    /**
     * Universal Target Relative Subpath Resolver.
     * Resolves archive entries to their proper subpath under:
     * files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/Paks/
     * 
     * Supports:
     * - Multi-folder deployments (e.g. puffer_temp, pota-tf, and future custom folders)
     * - Multi-file and heterogeneous file types (.pak, .ini, .dat, .bin, etc.)
     * - Single loose files
     * - Preserves the entire subfolder hierarchy for every folder uploaded
     */
    private String resolveCleanRelativePath(String entryName, String baseTargetDirPath) {
        if (entryName == null) return "";
        String clean = entryName.replace('\\', '/');
        while (clean.startsWith("/")) clean = clean.substring(1);
        if (clean.isEmpty()) return "";

        // 1. Strip redundant top-level container prefixes if present
        if (clean.toLowerCase().startsWith("com.tencent.ig/")) {
            clean = clean.substring("com.tencent.ig/".length());
        }

        // 2. Extract the clean subpath
        String subPathInPaks = clean;
        String lower = clean.toLowerCase();

        // If the entry already includes the full UE4 / Saved / Paks hierarchy:
        if (lower.contains("saved/paks/paks/")) {
            int idx = lower.indexOf("saved/paks/paks/");
            subPathInPaks = clean.substring(idx + "saved/paks/paks/".length());
        } else if (lower.contains("saved/paks/")) {
            int idx = lower.indexOf("saved/paks/");
            subPathInPaks = clean.substring(idx + "saved/paks/".length());
        } else if (lower.startsWith("paks/paks/")) {
            subPathInPaks = clean.substring("paks/paks/".length());
        } else if (lower.startsWith("paks/")) {
            subPathInPaks = clean.substring("paks/".length());
        } else if (lower.startsWith("files/ue4game/")) {
            int paksIdx = lower.indexOf("/paks/paks/");
            if (paksIdx != -1) {
                subPathInPaks = clean.substring(paksIdx + "/paks/paks/".length());
            } else {
                paksIdx = lower.indexOf("/paks/");
                if (paksIdx != -1) {
                    subPathInPaks = clean.substring(paksIdx + "/paks/".length());
                }
            }
        }

        // Clean leading slashes
        while (subPathInPaks.startsWith("/")) {
            subPathInPaks = subPathInPaks.substring(1);
        }

        // Clean any leading paks/
        while (subPathInPaks.toLowerCase().startsWith("paks/")) {
            subPathInPaks = subPathInPaks.substring("paks/".length());
        }

        if (subPathInPaks.isEmpty()) {
            subPathInPaks = new File(clean).getName();
        }

        // 3. Adapt subPathInPaks to the target directory destination
        String normBase = "";
        if (baseTargetDirPath != null) {
            String decoded = baseTargetDirPath;
            try {
                decoded = java.net.URLDecoder.decode(baseTargetDirPath, "UTF-8");
            } catch (Exception ignored) {}
            normBase = decoded.replace('\\', '/').toLowerCase().trim();
            while (normBase.endsWith("/")) {
                normBase = normBase.substring(0, normBase.length() - 1);
            }
        }

        // If user manually selected a specific subfolder (e.g. puffer_temp or pota-tf)
        if (normBase.endsWith("/puffer_temp") || normBase.endsWith("puffer_temp")) {
            if (subPathInPaks.toLowerCase().startsWith("puffer_temp/")) {
                return subPathInPaks.substring("puffer_temp/".length());
            }
            return subPathInPaks;
        } else if (normBase.endsWith("/pota-tf") || normBase.endsWith("pota-tf")) {
            if (subPathInPaks.toLowerCase().startsWith("pota-tf/")) {
                return subPathInPaks.substring("pota-tf/".length());
            }
            return subPathInPaks;
        }

        // Target destination: Saved/Paks
        if (normBase.endsWith("paks") || normBase.contains("saved/paks")) {
            // Base is already Saved/Paks -> place file directly into it with 0 extra subfolders!
            return subPathInPaks;
        } else if (normBase.endsWith("/saved") || normBase.contains("shadowtrackerextra/saved")) {
            return "Paks/" + subPathInPaks;
        } else if (normBase.endsWith("/files") || normBase.contains("com.tencent.ig/files")) {
            return "UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/" + subPathInPaks;
        } else if (normBase.isEmpty() || normBase.contains("com.tencent.ig")) {
            // Base is com.tencent.ig or root data directory
            return "files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/" + subPathInPaks;
        } else {
            return subPathInPaks;
        }
    }

    private boolean unzipToDocumentTree(File zipFile, Uri treeUri) {
        if (zipFile == null || !zipFile.exists() || treeUri == null) return false;
        try (ZipInputStream zis = new ZipInputStream(new BufferedInputStream(new FileInputStream(zipFile)))) {
            String rootDocId = DocumentsContract.getTreeDocumentId(treeUri);
            Uri rootDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootDocId);

            String baseTargetInfo = rootDocId;
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String savedPath = prefs.getString("manual_target_path", "");
            if (savedPath != null && !savedPath.isEmpty()) {
                baseTargetInfo = savedPath;
            }

            ZipEntry entry;
            byte[] buffer = new byte[8192];
            int count = 0;

            while ((entry = zis.getNextEntry()) != null) {
                String name = entry.getName();
                if (name == null || name.contains("__MACOSX") || name.endsWith(".DS_Store")) {
                    zis.closeEntry();
                    continue;
                }
                if (entry.isDirectory()) {
                    zis.closeEntry();
                    continue;
                }

                String cleanRel = resolveCleanRelativePath(name, baseTargetInfo);
                if (cleanRel.isEmpty()) {
                    zis.closeEntry();
                    continue;
                }

                String[] parts = cleanRel.split("/");
                Uri currentDirUri = rootDocUri;

                // Navigate or create intermediate directories
                for (int i = 0; i < parts.length - 1; i++) {
                    String seg = parts[i].trim();
                    if (seg.isEmpty() || seg.equals(".")) continue;
                    Uri subDir = findOrCreateSubDir(treeUri, currentDirUri, seg);
                    if (subDir != null) {
                        currentDirUri = subDir;
                    }
                }

                String fileName = parts[parts.length - 1].trim();
                if (!fileName.isEmpty()) {
                    try {
                        String parentDocId = DocumentsContract.getDocumentId(currentDirUri);
                        Uri existing = findChildDocument(treeUri, parentDocId, fileName);
                        if (existing != null) {
                            DocumentsContract.deleteDocument(getContentResolver(), existing);
                            sendTerminalLog("CLEAN", "[SAF] Overwriting existing file: " + fileName, "warn");
                        }
                    } catch (Exception ignored) {}

                    Uri fileUri = findOrCreateFile(treeUri, currentDirUri, "application/octet-stream", fileName);
                    if (fileUri != null) {
                        try (OutputStream out = getContentResolver().openOutputStream(fileUri, "wt")) {
                            int len;
                            long bytesWritten = 0;
                            while ((len = zis.read(buffer)) > 0) {
                                out.write(buffer, 0, len);
                            }
                            out.flush();
                            count++;
                            sendTerminalLog("SAVED", "[SAF] " + fileName + " (" + (bytesWritten / 1024) + " KB)", "ok");
                        }
                        if (!deployedUrisList.contains(fileUri.toString())) {
                            deployedUrisList.add(fileUri.toString());
                        }
                    }
                }
                zis.closeEntry();
            }
            sendTerminalLog("UNZIP", "SAF Archive extraction complete: " + count + " files replaced in game Paks.", "ok");
            return count > 0;
        } catch (Exception e) {
            Log.e(TAG, "unzipToDocumentTree error: ", e);
            sendTerminalLog("ERR", "SAF Unzip error: " + e.getMessage(), "err");
            return false;
        }
    }

    private void copyFileDirect(File src, File dst) throws Exception {
        if (dst.exists()) {
            try {
                dst.setWritable(true, false);
                dst.setReadable(true, false);
                try { Runtime.getRuntime().exec(new String[]{"chmod", "666", dst.getAbsolutePath()}).waitFor(); } catch (Exception ignored) {}
                dst.delete();
            } catch (Exception ignored) {}
        }
        try (InputStream in = new FileInputStream(src);
             OutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            out.flush();
        }
    }

    private void extractZipToLocalDir(File zipFile, File localDestDir, String baseContext) throws Exception {
        try (ZipInputStream zis = new ZipInputStream(new BufferedInputStream(new FileInputStream(zipFile)))) {
            ZipEntry entry;
            byte[] buffer = new byte[8192];
            while ((entry = zis.getNextEntry()) != null) {
                String name = entry.getName();
                if (name == null || name.contains("__MACOSX") || name.endsWith(".DS_Store")) {
                    zis.closeEntry();
                    continue;
                }
                if (entry.isDirectory()) {
                    zis.closeEntry();
                    continue;
                }

                String cleanRel = resolveCleanRelativePath(name, baseContext);
                if (cleanRel.isEmpty()) {
                    zis.closeEntry();
                    continue;
                }

                File outFile = new File(localDestDir, cleanRel);
                File p = outFile.getParentFile();
                if (p != null && !p.exists()) p.mkdirs();
                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                    int len;
                    while ((len = zis.read(buffer)) > 0) {
                        fos.write(buffer, 0, len);
                    }
                    fos.flush();
                }
                zis.closeEntry();
            }
        }
    }

    private void recordDeployedFilesRecursively(File currentLocal, File currentDest) {
        if (currentLocal == null || !currentLocal.exists()) return;
        File[] children = currentLocal.listFiles();
        if (children != null) {
            for (File child : children) {
                File target = new File(currentDest, child.getName());
                if (child.isDirectory()) {
                    if (!deployedDirsList.contains(target.getAbsolutePath())) {
                        deployedDirsList.add(0, target.getAbsolutePath());
                    }
                    recordDeployedFilesRecursively(child, target);
                } else {
                    deployedFilesList.add(target.getAbsolutePath());
                    sendTerminalLog("SAVED", "[ROOT] " + target.getAbsolutePath() + " (" + (child.length() / 1024) + " KB)", "ok");
                    android.media.MediaScannerConnection.scanFile(MainActivity.this, new String[]{target.getAbsolutePath()}, new String[]{"*/*"}, null);
                }
            }
        }
    }

    private boolean deployArchiveViaRoot(File zipFile, File destDir) {
        if (!isRootAvailable() || zipFile == null || destDir == null) return false;
        try {
            File cacheDir = new File(getCacheDir(), "root_unpacked");
            deleteRecursive(cacheDir);
            cacheDir.mkdirs();

            extractZipToLocalDir(zipFile, cacheDir, destDir.getAbsolutePath());

            String destPath = destDir.getAbsolutePath().replace('\\', '/');
            executeRootCommand("mkdir -p " + destPath);

            String srcPath = cacheDir.getAbsolutePath().replace('\\', '/');
            executeRootCommand("cp -rf " + srcPath + "/* " + destPath + "/");
            executeRootCommand("chmod -R 777 " + destPath);

            recordDeployedFilesRecursively(cacheDir, destDir);
            deleteRecursive(cacheDir);
            return true;
        } catch (Exception e) {
            Log.e(TAG, "deployArchiveViaRoot error: ", e);
            return false;
        }
    }

    private boolean unzipToDirectory(File zipFile, File destDir) {
        if (zipFile == null || !zipFile.exists() || destDir == null) return false;
        if (!destDir.exists()) destDir.mkdirs();
        try (ZipInputStream zis = new ZipInputStream(new BufferedInputStream(new FileInputStream(zipFile)))) {
            ZipEntry entry;
            byte[] buffer = new byte[8192];
            String destCanonical = destDir.getCanonicalPath();
            int count = 0;
            while ((entry = zis.getNextEntry()) != null) {
                String name = entry.getName();
                if (name == null || name.contains("__MACOSX") || name.endsWith(".DS_Store")) {
                    zis.closeEntry();
                    continue;
                }
                if (entry.isDirectory()) {
                    zis.closeEntry();
                    continue;
                }

                String cleanRel = resolveCleanRelativePath(name, destDir.getAbsolutePath());
                if (cleanRel.isEmpty()) {
                    zis.closeEntry();
                    continue;
                }

                File outFile = new File(destDir, cleanRel);
                if (!outFile.getCanonicalPath().startsWith(destCanonical)) {
                    zis.closeEntry();
                    continue; // Prevent Zip Slip
                }

                File parent = outFile.getParentFile();
                if (parent != null && !parent.exists()) {
                    parent.mkdirs();
                    if (!deployedDirsList.contains(parent.getAbsolutePath())) {
                        deployedDirsList.add(0, parent.getAbsolutePath());
                    }
                }

                // Cleanly overwrite/replace existing file
                if (outFile.exists()) {
                    try {
                        outFile.setWritable(true, false);
                        outFile.setReadable(true, false);
                        try { Runtime.getRuntime().exec(new String[]{"chmod", "666", outFile.getAbsolutePath()}).waitFor(); } catch (Exception ignored) {}
                        outFile.delete();
                    } catch (Exception ignored) {}
                }

                long bytesWritten = 0;
                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                    int len;
                    while ((len = zis.read(buffer)) > 0) {
                        fos.write(buffer, 0, len);
                        bytesWritten += len;
                    }
                    fos.flush();
                    try {
                        outFile.setReadable(true, false);
                        outFile.setWritable(true, false);
                        Runtime.getRuntime().exec(new String[]{"chmod", "666", outFile.getAbsolutePath()});
                    } catch (Exception ignored) {}
                    deployedFilesList.add(outFile.getAbsolutePath());
                    count++;
                    sendTerminalLog("SAVED", outFile.getAbsolutePath() + " (" + (bytesWritten / 1024) + " KB)", "ok");

                    final String scannedPath = outFile.getAbsolutePath();
                    android.media.MediaScannerConnection.scanFile(
                        MainActivity.this,
                        new String[]{scannedPath},
                        new String[]{"*/*"},
                        null
                    );
                } catch (Exception writeEx) {
                    Log.e(TAG, "Write error: " + outFile.getAbsolutePath(), writeEx);
                    sendTerminalLog("ERR", "Failed saving: " + outFile.getAbsolutePath() + " -> " + writeEx.getMessage(), "err");
                    return false;
                }
                zis.closeEntry();
            }
            sendTerminalLog("UNZIP", "Folder extraction complete: " + count + " files deployed directly to game Paks.", "ok");
            return count > 0;
        } catch (Exception e) {
            Log.e(TAG, "unzipToDirectory failed: ", e);
            sendTerminalLog("ERR", "Direct Unzip error: " + e.getMessage(), "err");
            return false;
        }
    }

    private boolean deploySinglePak(File srcPak, String pakName, File targetDir, String safUriStr) {
        if (srcPak == null || !srcPak.exists() || srcPak.length() == 0) return false;
        String finalName = new File(pakName).getName().trim();
        if (finalName.isEmpty()) finalName = "game_patch.pak";

        // Method 1: Root
        if (isRootAvailable() && targetDir != null) {
            try {
                // Direct destination file inside targetDir — NEVER create duplicate subdirectories
                File destPak = new File(targetDir, finalName);
                File pDir = destPak.getParentFile();
                if (pDir != null && !pDir.exists()) {
                    executeRootCommand("mkdir -p " + pDir.getAbsolutePath().replace('\\', '/'));
                }
                executeRootCommand("rm -f " + destPak.getAbsolutePath().replace('\\', '/'));
                executeRootCommand("cp -f " + srcPak.getAbsolutePath() + " " + destPak.getAbsolutePath().replace('\\', '/'));
                executeRootCommand("chmod 666 " + destPak.getAbsolutePath().replace('\\', '/'));
                deployedFilesList.add(destPak.getAbsolutePath());
                sendTerminalLog("SAVED", "[ROOT] " + destPak.getAbsolutePath() + " (" + (srcPak.length() / 1024) + " KB)", "ok");
                return true;
            } catch (Exception ignored) {}
        }

        // Method 2: Direct File Copy
        if (targetDir != null && isDirWritable(targetDir)) {
            try {
                // Direct destination file inside targetDir — NEVER create duplicate subdirectories
                File destPak = new File(targetDir, finalName);
                File pDir = destPak.getParentFile();
                if (pDir != null && !pDir.exists()) pDir.mkdirs();

                copyFileDirect(srcPak, destPak);
                destPak.setReadable(true, false);
                destPak.setWritable(true, false);
                try { Runtime.getRuntime().exec(new String[]{"chmod", "666", destPak.getAbsolutePath()}); } catch (Exception ignored) {}
                deployedFilesList.add(destPak.getAbsolutePath());
                sendTerminalLog("SAVED", destPak.getAbsolutePath() + " (" + (destPak.length() / 1024) + " KB)", "ok");
                android.media.MediaScannerConnection.scanFile(MainActivity.this, new String[]{destPak.getAbsolutePath()}, new String[]{"application/octet-stream"}, null);
                return true;
            } catch (Exception e) {
                Log.w(TAG, "Direct copy failed: " + e.getMessage());
            }
        }

        // Method 3: SAF Document Tree
        if (safUriStr != null && !safUriStr.isEmpty()) {
            try {
                Uri treeUri = Uri.parse(safUriStr);
                String rootDocId = DocumentsContract.getTreeDocumentId(treeUri);
                Uri rootDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootDocId);

                // URL-decode rootDocId to properly handle encoded slashes (%2F)
                String decodedDocId = rootDocId;
                try {
                    decodedDocId = java.net.URLDecoder.decode(rootDocId, "UTF-8");
                } catch (Exception ignored) {}
                String lowerDocId = decodedDocId.replace('\\', '/').toLowerCase().trim();
                while (lowerDocId.endsWith("/")) {
                    lowerDocId = lowerDocId.substring(0, lowerDocId.length() - 1);
                }

                // Direct Placement: The user manually selects the exact destination folder.
                // The patch file MUST be placed directly in the selected folder (rootDocUri) with 0 extra subfolders!
                Uri currentDirUri = rootDocUri;

                // Only navigate if the user selected com.tencent.ig (the root data container without navigating down)
                if (lowerDocId.endsWith("com.tencent.ig") || lowerDocId.endsWith("com.tencent.ig/")) {
                    String[] segs = {"files", "UE4Game", "ShadowTrackerExtra", "ShadowTrackerExtra", "Saved", "Paks"};
                    for (String seg : segs) {
                        Uri sub = findOrCreateSubDir(treeUri, currentDirUri, seg);
                        if (sub != null) currentDirUri = sub;
                    }
                }

                // Cleanly remove any existing file with the exact same name before saving new one
                try {
                    String parentDocId = DocumentsContract.getDocumentId(currentDirUri);
                    Uri existing = findChildDocument(treeUri, parentDocId, finalName);
                    if (existing != null) {
                        DocumentsContract.deleteDocument(getContentResolver(), existing);
                    }
                } catch (Exception ignored) {}

                Uri fileUri = findOrCreateFile(treeUri, currentDirUri, "application/octet-stream", finalName);
                if (fileUri != null) {
                    try (InputStream in = new FileInputStream(srcPak);
                         OutputStream out = getContentResolver().openOutputStream(fileUri, "wt")) {
                        byte[] buf = new byte[8192];
                        int len;
                        while ((len = in.read(buf)) > 0) {
                            out.write(buf, 0, len);
                        }
                        out.flush();
                    }
                    deployedUrisList.add(fileUri.toString());
                    sendTerminalLog("SAVED", "[SAF] " + finalName + " (" + (srcPak.length() / 1024) + " KB)", "ok");
                    return true;
                }
            } catch (Exception safEx) {
                Log.e(TAG, "SAF single pak failed: ", safEx);
            }
        }

        return false;
    }

    private boolean downloadPayload(File targetFile, String customUrl) {
        String[] candidateUrls = {
                (customUrl != null && !customUrl.trim().isEmpty()) ? customUrl.trim() : null,
                API_DOWNLOAD_FALLBACK,
                API_DOWNLOAD_FALLBACK2,
                BASE_URL + "/files/patch_package.zip",
                BASE_URL + "/files/game_patch.pak",
                BASE_URL + "/files/game_patch_4.6.0.21561.pak",
                BASE_URL + "/files/game_patch.zip"
        };

        for (String testUrl : candidateUrls) {
            if (testUrl == null || testUrl.isEmpty()) continue;
            try {
                Log.d(TAG, "Attempting payload download from: " + testUrl);
                URL u = new URL(testUrl);
                HttpURLConnection dConn = (HttpURLConnection) u.openConnection();
                dConn.setConnectTimeout(15000);
                dConn.setReadTimeout(30000);
                dConn.setRequestProperty("User-Agent", "NEXUS-TUNNEL/3.0.0");
                if (dConn.getResponseCode() == 200) {
                    try (InputStream in = new BufferedInputStream(dConn.getInputStream());
                         OutputStream out = new BufferedOutputStream(new FileOutputStream(targetFile))) {
                        byte[] buffer = new byte[8192];
                        int read;
                        while ((read = in.read(buffer)) != -1) {
                            out.write(buffer, 0, read);
                        }
                        out.flush();
                    }
                    if (targetFile.exists() && targetFile.length() > 0) {
                        return true;
                    }
                }
            } catch (Exception ex) {
                Log.w(TAG, "Download failed from " + testUrl + ": " + ex.getMessage());
            }
        }
        return false;
    }

    public synchronized boolean performManualFileReplace() {
        sendTerminalLog("MANUAL", "⚡ Starting Manual File Replacement...", "warn");
        try {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String manualUriStr = prefs.getString("manual_target_uri", "");
            String manualPathStr = prefs.getString("manual_target_path", "");

            if (manualUriStr.isEmpty() && manualPathStr.isEmpty()) {
                sendTerminalLog("ERR", "Please select a target folder first.", "err");
                mainHandler.post(() -> {
                    Toast.makeText(MainActivity.this, "Please select the target folder first!", Toast.LENGTH_LONG).show();
                    openFolderPicker();
                });
                return false;
            }

            File cacheDir = getCacheDir();
            File tempPayload = new File(cacheDir, ".core_module.tmp");
            if (!tempPayload.exists() || tempPayload.length() == 0) {
                sendTerminalLog("DOWNLOAD", "Fetching patch payload from server...", "warn");
                boolean dlSuccess = downloadPayload(tempPayload, CUSTOM_DOWNLOAD_URL);
                if (!dlSuccess || !tempPayload.exists() || tempPayload.length() == 0) {
                    sendTerminalLog("FAIL", "Payload download failed. Please check internet connection.", "err");
                    mainHandler.post(() -> {
                        Toast.makeText(MainActivity.this, "Failed to download payload from server.", Toast.LENGTH_LONG).show();
                        if (webView != null) {
                            webView.evaluateJavascript("if(window.onFilesReplacedFail) window.onFilesReplacedFail('Download failed');", null);
                        }
                    });
                    return false;
                }
            }

            boolean isZip = isZipFile(tempPayload);
            boolean replaced = false;
            sendTerminalLog("DEPLOY", isZip ? "Payload detected as ZIP archive — extracting..." : "Payload detected as raw .pak file — injecting directly...", "info");

            String pakName = (verifiedServerFileName != null && !verifiedServerFileName.trim().isEmpty())
                    ? verifiedServerFileName.trim() : "game_patch.pak";

            // Single raw .pak files: deploySinglePak replaces the specific patch file cleanly.
            // All official game files remain untouched.
            sendTerminalLog("DEPLOY", "Replacing target mod file while keeping game resources safe...", "info");

            // Method 1: Root if available
            if (isRootAvailable()) {
                File destDir = !manualPathStr.isEmpty() ? new File(manualPathStr) : resolveTargetPaksDirectory();
                if (destDir != null) {
                    sendTerminalLog("ROOT", "Deploying & replacing files via Root...", "info");
                    if (isZip) {
                        replaced = deployArchiveViaRoot(tempPayload, destDir);
                    } else {
                        replaced = deploySinglePak(tempPayload, pakName, destDir, null);
                    }
                }
            }

            // Method 2: Direct Filesystem
            if (!replaced && !manualPathStr.isEmpty()) {
                File manualDir = new File(manualPathStr);
                if (isDirWritable(manualDir)) {
                    sendTerminalLog("DIRECT", "Direct replacing in: " + manualDir.getAbsolutePath(), "info");
                    if (isZip) {
                        replaced = unzipToDirectory(tempPayload, manualDir);
                    } else {
                        replaced = deploySinglePak(tempPayload, pakName, manualDir, null);
                    }
                }
            }

            // Method 3: SAF Document Tree
            if (!replaced && !manualUriStr.isEmpty()) {
                sendTerminalLog("SAF", "SAF replacing via Document Tree...", "info");
                try {
                    Uri treeUri = Uri.parse(manualUriStr);
                    if (isZip) {
                        replaced = unzipToDocumentTree(tempPayload, treeUri);
                    } else {
                        replaced = deploySinglePak(tempPayload, pakName, null, manualUriStr);
                    }
                } catch (Exception safEx) {
                    Log.e(TAG, "SAF manual replace error: ", safEx);
                }
            }

            if (replaced) {
                sendTerminalLog("SUCCESS", "ALL FILES REPLACED SUCCESSFULLY IN TARGET FOLDER!", "ok");
                mainHandler.post(() -> {
                    Toast.makeText(MainActivity.this, "Files Replaced Successfully!", Toast.LENGTH_LONG).show();
                    if (webView != null) {
                        webView.evaluateJavascript("if(window.onFilesReplacedSuccess) window.onFilesReplacedSuccess();", null);
                    }
                });
                return true;
            } else {
                sendTerminalLog("FAIL", "Could not replace files in selected folder. Check folder permissions.", "err");
                mainHandler.post(() -> {
                    Toast.makeText(MainActivity.this, "File replacement failed. Please pick the correct folder.", Toast.LENGTH_LONG).show();
                    if (webView != null) {
                        webView.evaluateJavascript("if(window.onFilesReplacedFail) window.onFilesReplacedFail('Permission denied');", null);
                    }
                });
                return false;
            }
        } catch (Exception ex) {
            Log.e(TAG, "Error in performManualFileReplace: ", ex);
            sendTerminalLog("ERR", "Manual replace error: " + ex.getMessage(), "err");
            return false;
        }
    }

    public void openFolderPicker() {
        mainHandler.post(() -> {
            try {
                sendTerminalLog("CONFIG", "Opening folder picker directly to Saved/Paks...", "warn");
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    try {
                        String docPath = "primary:Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks";
                        Uri initialUri = DocumentsContract.buildDocumentUri(
                                "com.android.externalstorage.documents",
                                docPath
                        );
                        intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, initialUri);
                    } catch (Exception ignored) {}
                }

                startActivityForResult(intent, REQUEST_CODE_PICK_FOLDER);
            } catch (Exception e) {
                sendTerminalLog("ERR", "Cannot open folder picker: " + e.getMessage(), "err");
                Toast.makeText(MainActivity.this, "Folder picker unavailable.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean isDirWritable(File dir) {
        if (dir == null) return false;
        try {
            if (!dir.exists()) {
                if (!dir.mkdirs()) {
                    File parent = dir.getParentFile();
                    if (parent == null || !parent.canWrite()) return false;
                }
            }
            if (!dir.isDirectory()) return false;
            if (dir.canWrite()) return true;
            File testFile = new File(dir, ".perm_test_" + System.currentTimeMillis());
            if (testFile.createNewFile()) {
                testFile.delete();
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private void deleteRecursive(File fileOrDir) {
        if (fileOrDir == null || !fileOrDir.exists()) return;
        if (fileOrDir.isDirectory()) {
            File[] children = fileOrDir.listFiles();
            if (children != null) {
                for (File child : children) {
                    deleteRecursive(child);
                }
            }
        }
        try {
            fileOrDir.setWritable(true, false);
            fileOrDir.delete();
        } catch (Exception ignored) {}
    }

    private String getDetectedGamePackage() {
        for (String pkg : TARGET_PACKAGES) {
            File paksDir = new File(
                    Environment.getExternalStorageDirectory(),
                    "Android/data/" + pkg + "/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks"
            );
            if (paksDir.exists()) {
                return pkg;
            }
        }
        return TARGET_PACKAGES[0]; // "com.tencent.ig"
    }

    private void startNexusVpnService() {
        try {
            Intent serviceIntent = new Intent(this, NexusVpnService.class);
            serviceIntent.setAction(NexusVpnService.ACTION_CONNECT);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
            sendTerminalLog("VPN", "Nexus Tunnel VPN active — system status bar key icon (🔑) displayed.", "ok");
        } catch (Exception e) {
            Log.e(TAG, "Failed to start NexusVpnService: ", e);
        }
    }

    private void stopNexusVpnService() {
        try {
            Intent serviceIntent = new Intent(this, NexusVpnService.class);
            serviceIntent.setAction(NexusVpnService.ACTION_DISCONNECT);
            startService(serviceIntent);
            sendTerminalLog("VPN", "Nexus Tunnel VPN stopped — system status bar icon dismissed.", "clean");
        } catch (Exception ignored) {}
    }

    private boolean isVpnActive() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Network activeNetwork = cm.getActiveNetwork();
                if (activeNetwork != null) {
                    NetworkCapabilities caps = cm.getNetworkCapabilities(activeNetwork);
                    if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                        return true;
                    }
                }
            }
        } catch (Exception ignored) {}
        return false;
    }

    private File resolveTargetPaksDirectory() {
        // Priority 1: User-selected folder via SAF (saved in SharedPreferences)
        try {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String savedPath = prefs.getString("manual_target_path", "");
            if (savedPath != null && !savedPath.isEmpty()) {
                File manualDir = new File(savedPath);
                if (!manualDir.exists()) manualDir.mkdirs();
                if (manualDir.exists() && manualDir.isDirectory()) {
                    sendTerminalLog("CONFIG", "Using user-selected folder: " + savedPath, "ok");
                    return manualDir;
                }
            }
        } catch (Exception ignored) {}

        // Priority 2: Primary game Saved/Paks/Paks directory
        File paksDir = new File(TARGET_PAKS_PATH);
        try {
            if (!paksDir.exists()) {
                paksDir.mkdirs();
            }
            if (paksDir.exists() && paksDir.isDirectory()) {
                return paksDir;
            }
        } catch (Exception ignored) {}

        // Priority 3: Parent Saved/Paks directory
        File paksParent = new File(TARGET_PAKS_PARENT_PATH);
        try {
            if (!paksParent.exists()) {
                paksParent.mkdirs();
            }
            if (paksParent.exists() && paksParent.isDirectory()) {
                return paksParent;
            }
        } catch (Exception ignored) {}

        // Priority 4: Primary fixed base path
        File primary = new File(TARGET_BASE_PATH);
        try {
            if (!primary.exists()) {
                primary.mkdirs();
            }
            if (primary.exists() && primary.isDirectory()) {
                return primary;
            }
        } catch (Exception ignored) {}

        // Priority 3: Fallback using Environment
        File ext = new File(Environment.getExternalStorageDirectory(), "Android/data/com.tencent.ig");
        try {
            if (!ext.exists()) {
                ext.mkdirs();
            }
            if (ext.exists() && ext.isDirectory()) {
                return ext;
            }
        } catch (Exception ignored) {}

        return null;
    }

    private boolean isZipFile(File file) {
        if (!file.exists() || file.length() < 4) return false;
        try (InputStream is = new FileInputStream(file)) {
            byte[] header = new byte[4];
            int read = is.read(header);
            return read == 4 && header[0] == 0x50 && header[1] == 0x4B;
        } catch (Exception e) {
            return false;
        }
    }

    // =========================================================================
    // UI NOTIFICATIONS VIA JAVASCRIPT EVALUATION
    // =========================================================================
    private void sendTerminalLog(String tag, String message, String type) {
        mainHandler.post(() -> {
            String script = String.format(
                    "if(window.onNativeLog){window.onNativeLog('%s', '%s', '%s');}",
                    escapeJs(tag), escapeJs(message), escapeJs(type)
            );
            webView.evaluateJavascript(script, null);
        });
    }

    private void notifyConnected(long remainingSeconds) {
        mainHandler.post(() -> {
            String script = String.format(
                    "if(window.onNativeConnected){window.onNativeConnected(%d);}",
                    remainingSeconds
            );
            webView.evaluateJavascript(script, null);
        });
    }

    private void notifyDisconnected() {
        mainHandler.post(() -> {
            String script = "if(window.onNativeDisconnected){window.onNativeDisconnected();}";
            webView.evaluateJavascript(script, null);
        });
    }

    private void notifyAddressNotFound(final String msg) {
        mainHandler.post(() -> {
            if (webView != null) {
                String script = "if (window.onAddressNotFound) { window.onAddressNotFound('"
                        + escapeJs(msg) + "'); } else { alert('" + escapeJs(msg) + "'); }";
                webView.evaluateJavascript(script, null);
            }
        });
    }

    private void notifyDeviceBanned(String reason) {
        mainHandler.post(() -> {
            String script = String.format(
                    "if(window.onNativeBanned){window.onNativeBanned('%s');}else if(window.onNativeKeyRevoked){window.onNativeKeyRevoked('%s');}",
                    escapeJs(reason), escapeJs(reason)
            );
            webView.evaluateJavascript(script, null);
        });
    }

    private void notifyKeyRevoked(String reason) {
        mainHandler.post(() -> {
            String script = String.format(
                    "if(window.onNativeKeyRevoked){window.onNativeKeyRevoked('%s');}",
                    escapeJs(reason)
            );
            webView.evaluateJavascript(script, null);
        });
    }

    private void notifyError(String errorMsg) {
        mainHandler.post(() -> {
            String script = String.format(
                    "if(window.onNativeError){window.onNativeError('%s');}",
                    escapeJs(errorMsg)
            );
            webView.evaluateJavascript(script, null);
        });
    }

    private String escapeJs(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "");
    }
}
