package com.nexus.tunnel;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;


import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {

    private static final String TAG = "NexusTunnel";
    private static final String PREFS_NAME = "NexusPrefs";
    private static final String KEY_SAVED_LICENSE = "saved_license_key";

    // Server Configuration
    private static final String BASE_URL = "https://pubg.pakistanhandicraftbrass.com";
    private static final String API_VERIFY_ENDPOINT = BASE_URL + "/api/index.php";
    private static final String API_DOWNLOAD_FALLBACK = BASE_URL + "/api/patch/download";
    private static final String API_DOWNLOAD_FALLBACK2 = BASE_URL + "/server_api.php?action=download";

    // Target Packages for PUBG Mobile Variants
    private static final String[] TARGET_PACKAGES = {
            "com.tencent.ig",       // Global
            "com.pubg.imobile",     // BGMI (India)
            "com.pubg.krmobile",    // KR / JP
            "com.vng.pubgmobile",   // Vietnam
            "com.rekoo.pubgm"       // Taiwan
    };

    private WebView webView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final List<String> deployedFilesList = new ArrayList<>();
    private boolean isSessionActive = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Immersive Full Screen
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );

        webView = new WebView(this);
        setContentView(webView);

        configureWebView();
        requestAppPermissions();

        // Load Frosted Glass UI from local assets
        webView.loadUrl("file:///android_asset/index.html");
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        // Hardware Acceleration for smooth 60fps animations
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d(TAG, "Web UI Loaded Successfully: " + url);
            }
        });

        webView.setWebChromeClient(new WebChromeClient());

        // Register Java <-> JavaScript Bridge
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
    }

    private void requestAppPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            List<String> perms = new ArrayList<>();
            if (checkSelfPermission( Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            }
            if (checkSelfPermission( Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                perms.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            }
            if (!perms.isEmpty()) {
                requestPermissions( perms.toArray(new String[0]), 101);
            }
        }
    }

    // =========================================================================
    // JAVASCRIPT BRIDGE INTERFACE
    // =========================================================================
    public class AndroidBridge {

        @JavascriptInterface
        public String getSavedKey() {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            return prefs.getString(KEY_SAVED_LICENSE, "");
        }

        @JavascriptInterface
        public void saveKey(String key) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            prefs.edit().putString(KEY_SAVED_LICENSE, key != null ? key.trim() : "").apply();
        }

        @JavascriptInterface
        public void copyToClipboard(String text) {
            mainHandler.post(() -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null) {
                    ClipData clip = ClipData.newPlainText("Nexus Logs", text);
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(MainActivity.this, "Copied to Clipboard!", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void connect(final String key) {
            if (isSessionActive) {
                Log.w(TAG, "Connection session already active.");
                return;
            }
            executor.execute(() -> performConnectAndDeploy(key));
        }

        @JavascriptInterface
        public void disconnect() {
            executor.execute(() -> performDisconnectAndClean());
        }
    }

    // =========================================================================
    // CONNECT, VERIFY, DOWNLOAD & UNZIP PIPELINE
    // =========================================================================
    private void performConnectAndDeploy(String key) {
        try {
            sendTerminalLog("CONNECT", "Initiating secure handshake...", "warn");
            sendTerminalLog("PERMISSION", "Storage access verified from device.", "ok");

            String hwid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            if (hwid == null || hwid.isEmpty()) {
                hwid = "ANDROID-" + Build.SERIAL;
            }
            String deviceName = Build.MANUFACTURER + " " + Build.MODEL;

            // 1. Send API Verification Request
            sendTerminalLog("AUTH", "Verifying license key with security gateway...", "warn");

            String downloadUrl = null;
            long remainingSeconds = 30 * 86400L; // Default 30 days fallback
            boolean isAuthorized = false;

            // Test Master Key bypass or Live API verification
            if ("VIP-PAK-2026".equalsIgnoreCase(key.trim())) {
                isAuthorized = true;
                sendTerminalLog("AUTH", "Master VIP Key authenticated locally.", "ok");
            } else {
                try {
                    String postData = "action=" + URLEncoder.encode("verify_key", "UTF-8")
                            + "&key=" + URLEncoder.encode(key.trim(), "UTF-8")
                            + "&hwid=" + URLEncoder.encode(hwid, "UTF-8")
                            + "&device_name=" + URLEncoder.encode(deviceName, "UTF-8");

                    URL url = new URL(API_VERIFY_ENDPOINT);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    conn.setConnectTimeout(12000);
                    conn.setReadTimeout(12000);
                    conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    conn.setRequestProperty("User-Agent", "NEXUS-TUNNEL/3.0.0 (Android " + Build.VERSION.RELEASE + ")");

                    try (OutputStream os = conn.getOutputStream()) {
                        os.write(postData.getBytes(StandardCharsets.UTF_8));
                        os.flush();
                    }

                    int responseCode = conn.getResponseCode();
                    if (responseCode == 200) {
                        StringBuilder sb = new StringBuilder();
                        try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                            String line;
                            while ((line = reader.readLine()) != null) {
                                sb.append(line);
                            }
                        }

                        JSONObject json = new JSONObject(sb.toString());
                        String status = json.optString("status", "").toUpperCase();
                        String errorCode = json.optString("error_code", "");

                        if ("SUCCESS".equals(status) || "OK".equals(status) || json.optBoolean("valid", false)) {
                            isAuthorized = true;
                            if (json.has("download_url")) {
                                downloadUrl = json.getString("download_url");
                            }
                            if (json.has("remaining_seconds")) {
                                remainingSeconds = json.getLong("remaining_seconds");
                            }
                            sendTerminalLog("AUTH", "VIP Key successfully authenticated & hardware bound.", "ok");
                        } else {
                            String errMsg = "License authorization failed.";
                            if ("DEVICE_BANNED".equals(errorCode)) {
                                errMsg = "DEVICE BANNED: Hardware blocked by Admin!";
                            } else if ("DEVICE_LOCKED".equals(errorCode)) {
                                errMsg = "1-DEVICE LOCK: Key bound to another device!";
                            } else if ("EXPIRED".equals(status)) {
                                errMsg = "KEY EXPIRED: Please purchase a new VIP key.";
                            }
                            sendTerminalLog("FAIL", errMsg, "err");
                            notifyError(errMsg);
                            return;
                        }
                    } else {
                        sendTerminalLog("WARN", "Server responded with HTTP " + responseCode + ". Attempting fallback.", "warn");
                        isAuthorized = true;
                    }
                } catch (Exception e) {
                    Log.e(TAG, "API verification network error: ", e);
                    sendTerminalLog("WARN", "Cloud gateway timeout: Operating in resilient cached mode.", "warn");
                    isAuthorized = true;
                }
            }

            if (!isAuthorized) {
                notifyError("Invalid license key.");
                return;
            }

            // 2. Download Server Payload (ZIP archive)
            sendTerminalLog("DOWNLOAD", "Fetching payload from server...", "warn");

            File cacheDir = getCacheDir();
            File tempZip = new File(cacheDir, "server_payload.zip");
            boolean downloadSuccess = false;

            String[] candidateUrls = {
                    downloadUrl,
                    API_DOWNLOAD_FALLBACK,
                    API_DOWNLOAD_FALLBACK2,
                    BASE_URL + "/files/game_patch.zip",
                    BASE_URL + "/files/game_patch.pak"
            };

            for (String testUrl : candidateUrls) {
                if (testUrl == null || testUrl.isEmpty()) continue;
                try {
                    Log.d(TAG, "Attempting payload download from: " + testUrl);
                    URL u = new URL(testUrl);
                    HttpURLConnection dConn = (HttpURLConnection) u.openConnection();
                    dConn.setConnectTimeout(15000);
                    dConn.setReadTimeout(30000);
                    dConn.setRequestProperty("User-Agent", "NEXUS-TUNNEL/3.0.0");
                    if (dConn.getResponseCode() == 200) {
                        try (InputStream in = new BufferedInputStream(dConn.getInputStream());
                             OutputStream out = new BufferedOutputStream(new FileOutputStream(tempZip))) {
                            byte[] buffer = new byte[8192];
                            int read;
                            while ((read = in.read(buffer)) != -1) {
                                out.write(buffer, 0, read);
                            }
                            out.flush();
                        }
                        if (tempZip.exists() && tempZip.length() > 0) {
                            downloadSuccess = true;
                            sendTerminalLog("IDENTIFY", "Server payload identified: Multi-directory ZIP archive (" + (tempZip.length() / 1024) + " KB).", "info");
                            break;
                        }
                    }
                } catch (Exception ex) {
                    Log.w(TAG, "Download failed from " + testUrl + ": " + ex.getMessage());
                }
            }

            // 3. Identify Target Directory on Android
            File targetPaksDir = resolveTargetPaksDirectory();
            sendTerminalLog("TARGET", "Root: " + targetPaksDir.getAbsolutePath(), "info");

            if (!targetPaksDir.exists()) {
                targetPaksDir.mkdirs();
            }

            // 4. UNZIP AND DEPLOY FILES
            sendTerminalLog("UNZIP", "[STEP 1/3] Decompressing archive structure...", "warn");
            deployedFilesList.clear();

            if (downloadSuccess && tempZip.exists()) {
                boolean isZip = isZipFile(tempZip);
                if (isZip) {
                    // Extract all entries from ZIP
                    sendTerminalLog("DEPLOY", "[STEP 2/3] Extracting files into Saved/Paks hierarchy...", "warn");
                    try (ZipInputStream zis = new ZipInputStream(new BufferedInputStream(new FileInputStream(tempZip)))) {
                        ZipEntry entry;
                        byte[] buf = new byte[8192];
                        while ((entry = zis.getNextEntry()) != null) {
                            String entryName = entry.getName();
                            // Prevent Zip Slip vulnerability
                            File destFile = new File(targetPaksDir, entryName);
                            String destPath = destFile.getCanonicalPath();
                            if (!destPath.startsWith(targetPaksDir.getCanonicalPath())) {
                                zis.closeEntry();
                                continue;
                            }

                            if (entry.isDirectory()) {
                                destFile.mkdirs();
                            } else {
                                File parent = destFile.getParentFile();
                                if (parent != null && !parent.exists()) {
                                    parent.mkdirs();
                                }
                                try (FileOutputStream fos = new FileOutputStream(destFile)) {
                                    int count;
                                    while ((count = zis.read(buf)) != -1) {
                                        fos.write(buf, 0, count);
                                    }
                                    fos.flush();
                                }
                                deployedFilesList.add(destFile.getAbsolutePath());
                                Log.d(TAG, "Extracted: " + destFile.getAbsolutePath());
                            }
                            zis.closeEntry();
                        }
                    }
                } else {
                    // Direct binary/pak payload
                    File destPak = new File(targetPaksDir, "game_patch.pak");
                    copyFile(tempZip, destPak);
                    deployedFilesList.add(destPak.getAbsolutePath());
                }
            } else {
                // If remote server has no binary payload yet, create verified runtime token
                File tokenFile = new File(targetPaksDir, "nexus_session.cfg");
                try (FileOutputStream fos = new FileOutputStream(tokenFile)) {
                    fos.write(("NEXUS_SESSION=ACTIVE\nKEY=" + key + "\nTIMESTAMP=" + System.currentTimeMillis()).getBytes());
                }
                deployedFilesList.add(tokenFile.getAbsolutePath());
            }

            // 5. Complete & Notify UI
            isSessionActive = true;
            sendTerminalLog("SUCCESS", "[STEP 3/3] Deployment complete. 0 errors.", "ok");
            sendTerminalLog("NET", "Tunnel routing 100% ACTIVE and secured.", "ok");
            notifyConnected(remainingSeconds);

        } catch (Exception e) {
            Log.e(TAG, "Error in performConnectAndDeploy: ", e);
            sendTerminalLog("FAIL", "Deployment failed: " + e.getMessage(), "err");
            notifyError("Deployment failed: " + e.getMessage());
        }
    }

    private void performDisconnectAndClean() {
        try {
            sendTerminalLog("DISCONNECT", "Stopping tunnel session...", "warn");

            // Purge all extracted files
            for (String filePath : deployedFilesList) {
                try {
                    File f = new File(filePath);
                    if (f.exists()) {
                        f.delete();
                        Log.d(TAG, "Purged file: " + filePath);
                    }
                } catch (Exception ignored) {}
            }
            deployedFilesList.clear();

            // Clean cache
            File tempZip = new File(getCacheDir(), "server_payload.zip");
            if (tempZip.exists()) {
                tempZip.delete();
            }

            isSessionActive = false;
            sendTerminalLog("CLEAN", "All injected files purged. 0 traces remaining.", "clean");
            notifyDisconnected();

        } catch (Exception e) {
            Log.e(TAG, "Error in disconnect: ", e);
            notifyDisconnected();
        }
    }

    // =========================================================================
    // HELPER FUNCTIONS
    // =========================================================================
    private File resolveTargetPaksDirectory() {
        for (String pkg : TARGET_PACKAGES) {
            File paksDir = new File(
                    Environment.getExternalStorageDirectory(),
                    "Android/data/" + pkg + "/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks"
            );
            if (paksDir.exists()) {
                return paksDir;
            }
        }

        File defaultPaks = new File(
                Environment.getExternalStorageDirectory(),
                "Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks"
        );
        if (defaultPaks.getParentFile() != null && defaultPaks.getParentFile().exists()) {
            return defaultPaks;
        }

        File downloadPaks = new File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "NEXUS_Paks"
        );
        if (!downloadPaks.exists()) {
            downloadPaks.mkdirs();
        }
        return downloadPaks;
    }

    private boolean isZipFile(File file) {
        if (!file.exists() || file.length() < 4) return false;
        try (InputStream is = new FileInputStream(file)) {
            byte[] header = new byte[4];
            int read = is.read(header);
            return read == 4 && header[0] == 0x50 && header[1] == 0x4B;
        } catch (Exception e) {
            return false;
        }
    }

    private void copyFile(File src, File dst) throws Exception {
        try (InputStream in = new FileInputStream(src);
             OutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            out.flush();
        }
    }

    // =========================================================================
    // UI NOTIFICATIONS VIA JAVASCRIPT EVALUATION
    // =========================================================================
    private void sendTerminalLog(String tag, String message, String type) {
        mainHandler.post(() -> {
            String script = String.format(
                    "if(window.onNativeLog){window.onNativeLog('%s', '%s', '%s');}",
                    escapeJs(tag), escapeJs(message), escapeJs(type)
            );
            webView.evaluateJavascript(script, null);
        });
    }

    private void notifyConnected(long remainingSeconds) {
        mainHandler.post(() -> {
            String script = String.format(
                    "if(window.onNativeConnected){window.onNativeConnected(%d);}",
                    remainingSeconds
            );
            webView.evaluateJavascript(script, null);
        });
    }

    private void notifyDisconnected() {
        mainHandler.post(() -> {
            String script = "if(window.onNativeDisconnected){window.onNativeDisconnected();}";
            webView.evaluateJavascript(script, null);
        });
    }

    private void notifyError(String errorMsg) {
        mainHandler.post(() -> {
            String script = String.format(
                    "if(window.onNativeError){window.onNativeError('%s');}",
                    escapeJs(errorMsg)
            );
            webView.evaluateJavascript(script, null);
        });
    }

    private String escapeJs(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "");
    }
}
